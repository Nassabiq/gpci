@extends('adminlte::page')
@section('title', 'Import Checklist Dokumen')
@section('content')
    <div class="container">
        @livewire('checklist-dokumen')
    </div>
@endsection
