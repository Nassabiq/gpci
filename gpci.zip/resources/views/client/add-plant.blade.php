@extends('adminlte::page')
@section('title', 'Input Data Sertifikasi')
@section('content')
    <div class="container">
        @livewire('wizard-plant')
    </div>
@endsection
