@extends('adminlte::page')
@section('title', 'Approve Document')
@section('content')
    @livewire('approve-dokumen')
@endsection
