@extends('adminlte::page')
@section('title', 'Input Data Sertifikasi')
@section('content')
    <div class="container">
        @livewire('wizard-produk')
    </div>
@endsection
