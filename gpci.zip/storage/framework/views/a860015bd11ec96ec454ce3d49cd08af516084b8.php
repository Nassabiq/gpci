<div>
    <div class="row">
        <div class="col-lg-4 header">
            <div class="vrtwiz card">
                <ul class="verticalwiz card-body container mt-4">
                    <li class="<?php echo e($currentStep != 1 ? '' : 'active'); ?> d-flex">
                        <a href="#" class="active"> <span class="step">1</span></a>
                        <p class="title">Informasi Perusahaan</p>
                    </li>
                    <li class="<?php echo e($currentStep != 2 ? '' : 'active'); ?> d-flex">
                        <a href="#"> <span class="step">2</span> </a>
                        <p class="title">Informasi Fasilitas Produksi</p>
                    </li>
                    <li class="<?php echo e($currentStep != 3 ? '' : 'active'); ?> d-flex">
                        <a href="#"> <span class="step">3</span> </a>
                        <p class="title">Informasi Produk</p>
                    </li>
                    <li class="<?php echo e($currentStep != 4 ? '' : 'active'); ?> d-flex">
                        <a href="#"> <span class="step">4</span> </a>
                        <p class="title">Submission</p>
                    </li>
                </ul>
            </div>
        </div>

        <div class="col-lg-8 card card-outline card-teal">
            <div class="container p-4">
                <div class="card-body setup-content <?php echo e($currentStep != 1 ? 'displayNone' : ''); ?>" id="step1">
                    
                    <div class="col-md-12">
                        <h3 class="mx-0">Informasi Perusahaan</h3>
                        <hr>
                        
                        <div class="form-group row">
                            <label>Nama Perusahaan:</label>
                            <input type="text" wire:model="nama_perusahaan" class="form-control form-control-sm"
                                id="nama_perusahaan" placeholder="Nama Perusahaan ...">
                            <?php $__errorArgs = ['nama_perusahaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="form-group row">
                            <label>Email:</label>
                            <input type="email" wire:model="email_perusahaan" class="form-control form-control-sm"
                                id="email_perusahaan" placeholder="Email Perusahaan ...">
                            <?php $__errorArgs = ['email_perusahaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="form-group row">
                            <label>Alamat Perusahaan:</label>
                            <input type="text" wire:model="alamat_perusahaan" class="form-control form-control-sm"
                                id="alamat_perusahaan" placeholder="Alamat Perusahaan ...">
                            <?php $__errorArgs = ['alamat_perusahaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        
                        <div class="row">
                            <div class="form-group col-lg-2 col-md-2 col-sm-12 pl-0">
                                <label for="title">Kode Pos:</label>
                                <input type="text" wire:model="kodepos_perusahaan" class="form-control form-control-sm"
                                    id="kodepos_perusahaan" placeholder="Kode Pos...">
                                <?php $__errorArgs = ['kodepos_perusahaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group col-5 col-md-5 col-sm-6 col-6 pl-0">
                                <label for="title">No Telp:</label>
                                <input type="text" wire:model="no_telp_perusahaan" class="form-control form-control-sm"
                                    id="no_telp_perusahaan" placeholder="No. Telp ...">
                                <?php $__errorArgs = ['no_telp_perusahaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group col-5 col-md-5 col-sm-6 col-6 pl-0">
                                <label for="title">Fax:</label>
                                <input type="text" wire:model="fax_perusahaan" class="form-control form-control-sm"
                                    id="fax_perusahaan" placeholder="Fax ...">
                                <?php $__errorArgs = ['fax_perusahaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        
                        <div class="row">
                            <div class="form-group col-lg-6 col-md-6 col-sm-12 pl-0">
                                <label for="title">No Akta Notaris:</label>
                                <input type="text" wire:model="no_akta_notaris" class="form-control form-control-sm"
                                    id="no_akta_notaris" placeholder="No. Akta Notaris ...">
                                <?php $__errorArgs = ['no_akta_notaris'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group col-lg-6 col-md-6 col-sm-12 pl-0">
                                <label for="title">No. Surat Izin Usaha Perdagangan (SIUP):</label>
                                <input type="text" wire:model="no_siup" class="form-control form-control-sm"
                                    id="no_siup" placeholder="No. SIUP ...">
                                <?php $__errorArgs = ['no_siup'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        
                        <div class="row">
                            <div class="form-group col-lg-6 col-md-6 col-12 pl-0">
                                <label for="title">No. Tanda Daftar Perusahaan (TDP):</label>
                                <input type="text" wire:model="no_tdp" class="form-control form-control-sm" id="no_tdp"
                                    placeholder="No. TDP ...">
                                <?php $__errorArgs = ['no_tdp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group col-lg-6 col-md-6 col-12 pl-0">
                                <label for="title">NPWP:</label>
                                <input type="text" wire:model="no_npwp" class="form-control form-control-sm"
                                    id="no_npwp" placeholder="No. NPWP ...">
                                <?php $__errorArgs = ['no_npwp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        
                        <div class="form-group row">
                            <label>No. Angka Pengenal Importir(API):</label>
                            <input type="text" wire:model="no_api" class="form-control form-control-sm" id="no_api"
                                placeholder="No. API ...">
                            <?php $__errorArgs = ['no_api'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="row">
                            <div class="form-group col-lg-6 col-md-6 col-12 pl-0">
                                <label for="title">Apakah Anda Pernah Mendaftar Sertifikasi Ekolabel?</label> <br>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="sertifikasi_ekolabel"
                                        id="radio_yes" value="0" wire:model="sertifikasi_ekolabel">
                                    <label class="form-check-label">Iya</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="sertifikasi_ekolabel"
                                        id="radio_tidak" value="1" wire:model="sertifikasi_ekolabel">
                                    <label class="form-check-label">Tidak</label>
                                </div>
                            </div>
                            <div class="form-group col-lg-6 col-md-6 col-12 pl-0  <?php echo e($sertifikasi_ekolabel != 0 ? 'displayNone' : ''); ?>"
                                id="lembaga">
                                <label for="title">Jika Pernah, Sebutkan Nama Lembaganya: <sup
                                        class="text-danger">*optional</sup></label>
                                <input type="text" wire:model="lembaga_ekolabel" class="form-control form-control-sm"
                                    id="lembaga_ekolabel" placeholder="Lembaga Ekolabel..." value="2">
                                <?php $__errorArgs = ['lembaga_ekolabel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label>Website Perusahaan:</label>
                            <input type="text" wire:model="website_perusahaan" class="form-control form-control-sm"
                                id="website_perusahaan" placeholder="Website Perusahaan ...">
                            <?php $__errorArgs = ['website_perusahaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="contact-person-1">
                            <div class="form-group row">
                                <label class="col-12 px-0">Contact Person 1:</label> <br>
                                
                                <div class="cp col-lg-6 col-md-12 col-12 pl-0">
                                    <input type="text" wire:model="nama1" class="form-control form-control-sm"
                                        id="nama1" placeholder="Nama ...">
                                    <?php $__errorArgs = ['nama1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <div class="cp col-lg-6 col-md-12 col-12 px-0">
                                    <input type="text" wire:model="jabatan1" class="form-control form-control-sm"
                                        id="jabatan1" placeholder="Jabatan...">
                                    <?php $__errorArgs = ['jabatan1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                
                                <div class="cp col-lg-6 col-md-12 col-12 pl-0">
                                    <input type="text" wire:model="no_hp1" class="form-control form-control-sm"
                                        id="no_hp1" placeholder="No Handphone (WA) ...">
                                    <?php $__errorArgs = ['no_hp1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <div class="cp col-lg-6 col-md-12 col-12 px-0">
                                    <input type="email" wire:model="email1" class="form-control form-control-sm"
                                        id="email1" placeholder="Email...">
                                    <?php $__errorArgs = ['email1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                
                                <div class="cp col-lg-6 col-md-12 col-12 pl-0">
                                    <input type="text" wire:model="no_telp1" class="form-control form-control-sm"
                                        id="no_telp1" placeholder="No Telp ...">
                                    <?php $__errorArgs = ['no_telp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <div class="cp col-lg-6 col-md-12 col-12 px-0">
                                    <input type="text" wire:model="fax1" class="form-control form-control-sm" id="fax1"
                                        placeholder="No Fax...">
                                    <?php $__errorArgs = ['fax1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div class="contact-person-2">
                            <div class="form-group row">
                                <label class="col-12 px-0">Contact Person 2: <sup class="text-danger">*optional</sup>
                                </label> <br>
                                
                                <div class="cp col-lg-6 col-md-12 col-12 pl-0">
                                    <input type="text" wire:model="nama2" class="form-control form-control-sm"
                                        id="nama2" placeholder="Nama ...">
                                    <?php $__errorArgs = ['nama2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <div class="cp col-lg-6 col-md-12 col-12 px-0">
                                    <input type="text" wire:model="jabatan2" class="form-control form-control-sm"
                                        id="jabatan2" placeholder="Jabatan...">
                                    <?php $__errorArgs = ['jabatan2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                
                                <div class="cp col-lg-6 col-md-12 col-12 pl-0">
                                    <input type="text" wire:model="no_hp2" class="form-control form-control-sm"
                                        id="no_hp2" placeholder="No Handphone (WA) ...">
                                    <?php $__errorArgs = ['no_hp2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <div class="cp col-lg-6 col-md-12 col-12 px-0">
                                    <input type="email" wire:model="email2" class="form-control form-control-sm"
                                        id="email2" placeholder="Email...">
                                    <?php $__errorArgs = ['email2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                
                                <div class="cp col-lg-6 col-md-12 col-12 pl-0">
                                    <input type="text" wire:model="no_telp2" class="form-control form-control-sm"
                                        id="no_telp2" placeholder="No Telp ...">
                                    <?php $__errorArgs = ['no_telp2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <div class="cp col-lg-6 col-md-12 col-12 px-0">
                                    <input type="text" wire:model="fax2" class="form-control form-control-sm" id="fax2"
                                        placeholder="No Fax...">
                                    <?php $__errorArgs = ['fax2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <br>
                        <button class="btn btn-primary nextBtn pull-right next-button" type="button"
                            wire:click="firstStepSubmit">Next <i class="fas fa-long-arrow-alt-right pl-2"></i></button>

                        
                    </div>
                </div>
                <div class="card-body setup-content <?php echo e($currentStep != 2 ? 'displayNone' : ''); ?>" id="step2">

                    <div class="col-md-12">
                        <h3>Informasi Fasilitas Produksi</h3>
                        <hr>
                        
                        <div class="form-group row">
                            <label>Nama Pabrik:</label>
                            <input type="text" wire:model="nama_fasilitas" class="form-control form-control-sm"
                                id="nama_fasilitas" placeholder="Nama Pabrik ...">
                            <?php $__errorArgs = ['nama_fasilitas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="form-group row">
                            <label>Email:</label>
                            <input type="email" wire:model="email_fasilitas" class="form-control form-control-sm"
                                id="email_fasilitas" placeholder="Email Pabrik ...">
                            <?php $__errorArgs = ['email_fasilitas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="form-group row">
                            <label>Alamat Pabrik:</label>
                            <input type="text" wire:model="alamat_fasilitas" class="form-control form-control-sm"
                                id="alamat_fasilitas" placeholder="Alamat Pabrik ...">
                            <?php $__errorArgs = ['alamat_fasilitas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="row">
                            <div class="form-group col-lg-2 col-md-2 col-sm-12 pl-0">
                                <label for="title">Kode Pos:</label>
                                <input type="text" wire:model="kodepos_fasilitas" class="form-control form-control-sm"
                                    id="kodepos_fasilitas" placeholder="Kode Pos...">
                                <?php $__errorArgs = ['kodepos_fasilitas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group col-5 col-md-5 col-sm-6 col-6 pl-0">
                                <label for="title">No Telp:</label>
                                <input type="text" wire:model="no_telp_fasilitas" class="form-control form-control-sm"
                                    id="no_telp_fasilitas" placeholder="No. Telp ...">
                                <?php $__errorArgs = ['no_telp_fasilitas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group col-5 col-md-5 col-sm-6 col-6 pl-0">
                                <label for="title">Fax:</label>
                                <input type="text" wire:model="fax_fasilitas" class="form-control form-control-sm"
                                    id="fax_fasilitas" placeholder="Fax ...">
                                <?php $__errorArgs = ['fax_fasilitas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        
                        <div class="form-group row">
                            <label class="col-12 px-0">Contact Person:</label> <br>
                            
                            <div class="cp col-lg-6 col-md-12 col-12 pl-0">
                                <input type="text" wire:model="nama3" class="form-control form-control-sm" id="nama3"
                                    placeholder="Nama ...">
                                <?php $__errorArgs = ['nama3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div class="cp col-lg-6 col-md-12 col-12 px-0">
                                <input type="text" wire:model="jabatan3" class="form-control form-control-sm"
                                    id="jabatan3" placeholder="Jabatan...">
                                <?php $__errorArgs = ['jabatan3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            
                            <div class="cp col-lg-6 col-md-12 col-12 pl-0">
                                <input type="text" wire:model="no_hp3" class="form-control form-control-sm" id="no_hp3"
                                    placeholder="No Handphone (WA) ...">
                                <?php $__errorArgs = ['no_hp3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div class="cp col-lg-6 col-md-12 col-12 px-0">
                                <input type="email" wire:model="email3" class="form-control form-control-sm" id="email3"
                                    placeholder="Email...">
                                <?php $__errorArgs = ['email3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            
                            <div class="cp col-lg-6 col-md-12 col-12 pl-0">
                                <input type="text" wire:model="no_telp3" class="form-control form-control-sm"
                                    id="no_telp3" placeholder="No Telp ...">
                                <?php $__errorArgs = ['no_telp3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div class="cp col-lg-6 col-md-12 col-12 px-0">
                                <input type="text" wire:model="fax3" class="form-control form-control-sm" id="fax3"
                                    placeholder="No Fax...">
                                <?php $__errorArgs = ['fax3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <button class="btn btn-primary nextBtn pull-right next-button" type="submit"
                            wire:click="secondStepSubmit">Next <i class="fas fa-long-arrow-alt-right pl-2"></i></button>
                        <button type="button" class="btn btn-danger nextBtn pull-right prev-button"
                            wire:click="back(1)"><i class="fas fa-long-arrow-alt-left pr-2"></i> Back</button>
                    </div>
                </div>
                <div class="card-body setup-content <?php echo e($currentStep != 3 ? 'displayNone' : ''); ?>" id="step3">
                    
                    <div class="col-md-12">
                        <h3>Informasi Produk</h3>
                        <hr>
                        
                        <div class="form-group row">
                            <label>Nama Produk:</label>
                            <input type="text" wire:model="nama_produk" class="form-control form-control-sm"
                                id="nama_produk" placeholder="Nama Produk ...">
                            <?php $__errorArgs = ['nama_produk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group row">
                            <label>Tipe / Model:</label>
                            <input type="text" wire:model="tipe_model" class="form-control form-control-sm"
                                id="tipe_model" placeholder="Tipe / Model ...">
                            <?php $__errorArgs = ['tipe_model'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group row">
                            
                            <div class="cp col-lg-3 col-md-12 col-12 pl-0">
                                <label>Ukuran</label>
                                <input type="text" wire:model="ukuran" class="form-control form-control-sm" id="ukuran"
                                    placeholder="Ukuran...">
                                <?php $__errorArgs = ['ukuran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div class="cp col-lg-9 col-md-12 col-12 px-0">
                                <label>Merk Dagang:</label>
                                <input type="text" wire:model="merk_dagang" class="form-control form-control-sm"
                                    id="merk_dagang" placeholder="Merk Dagang...">
                                <?php $__errorArgs = ['merk_dagang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        
                        <div class="form-group row">
                            <label>Deskripsi Produk:</label>
                            <textarea class="form-control" id="deskripsi" rows="3"
                                wire:model="deskripsi_produk"></textarea>
                            <?php $__errorArgs = ['deskripsi_produk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="form-group row">
                            <label>Produk yang akan disertifikasi:</label>
                            <select class="custom-select custom-select-sm" wire:model="kategori_produk"
                                id="inputGroupSelect02">
                                <option value="">Choose...</option>
                                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>">
                                        <?php echo e($item->categories); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        
                        <div class="form-group row">
                            <label>Jenis Sertifikasi :</label>
                            <select class="form-control form-control-sm" wire:model="jenis_sertifikasi">
                                <option>Jenis Sertifikasi</option>
                                <option value="1">Pengajuan Baru</option>
                                <option value="2">Perpanjangan</option>
                            </select>
                            <?php $__errorArgs = ['jenis_sertifikasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <label>Foto Produk:</label>
                        <div class="input-group mb-3 mx-0">
                            <div class="custom-file">
                                <input type="file" class="custom-file-input"  name="foto_produk[]"
                                    wire:model="foto_produk" multiple id="photoproduk">
                                <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                            </div>
                        </div>
                        <?php $__currentLoopData = $foto_produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card d-inline-block">
                                <?php if($photos): ?>
                                    <div class="card-body">
                                        <img width="150px" height="150px" style="object-fit: cover"
                                            src="<?php echo e($photos->temporaryUrl()); ?>">
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__errorArgs = ['foto_produk.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        
                        
                        <div class="form-group row">
                            <label>Tipe Pengemasan dan Ukuran:</label>
                            <input type="text" wire:model="tipe_pengemasan" class="form-control form-control-sm"
                                id="tipe_pengemasan" placeholder="Tipe Pengemasan dan Ukuran ...">
                            <?php $__errorArgs = ['tipe_pengemasan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <button class="btn btn-primary nextBtn next-button pull-right" wire:click="thirdStepSubmit"
                            type="button">Next <i class="fas fa-long-arrow-alt-right pl-2"></i></button>
                        <button class="btn btn-danger nextBtn prev-button pull-right" type="button"
                            wire:click="back(2)"><i class="fas fa-long-arrow-alt-left pr-2"></i> Back</button>
                    </div>
                </div>
                <div class="card-body setup-content <?php echo e($currentStep != 4 ? 'displayNone' : ''); ?>" id="step4">
                    <div class="col-md-12 konfirmasi">
                        <h3>Konfirmasi Pendaftaran Sertifikasi</h3>
                        <hr>
                        <h5>Informasi Perusahaan</h5>
                        <table class="table table-sm table-borderless">
                            <tbody>
                                <tr>
                                    <td class="table-first">Nama Perusahaan</td>
                                    <td>:</td>
                                    <td><?php echo e($nama_perusahaan); ?></td>
                                </tr>
                                <tr>
                                    <td class="table-first">Alamat</td>
                                    <td>:</td>
                                    <td><?php echo e($alamat_perusahaan); ?></td>
                                </tr>
                            </tbody>
                        </table>
                        <div class="row">
                            <div class="col-6">
                                <table class="table table-sm table-borderless">
                                    <tbody>
                                        <tr>
                                            <td class="table-first">Email</td>
                                            <td class="table-second">:</td>
                                            <td class="table-third"><?php echo e($email_perusahaan); ?></td>
                                        </tr>
                                        <tr>
                                            <td class="table-first">No Telp</td>
                                            <td class="table-second">:</td>
                                            <td class="table-third"><?php echo e($no_telp_perusahaan); ?></td>
                                        </tr>
                                        <tr>
                                            <td class="table-first">No Akta Notaris</td>
                                            <td class="table-second">:</td>
                                            <td class="table-third"><?php echo e($no_akta_notaris); ?></td>
                                        </tr>
                                        <tr>
                                            <td class="table-first">Nomor TDP</td>
                                            <td class="table-second">:</td>
                                            <td class="table-third"><?php echo e($no_tdp); ?></td>
                                        </tr>
                                        <tr>
                                            <td class="table-first">Nomor API</td>
                                            <td class="table-second">:</td>
                                            <td class="table-third"><?php echo e($no_api); ?></td>
                                        </tr>
                                        <tr>
                                            <td class="table-first">Sertifikasi Ekolabel</td>
                                            <td class="table-second">:</td>
                                            <td class="table-third">
                                                <?php echo e($sertifikasi_ekolabel == 0 ? 'Iya' : 'Tidak'); ?>

                                            </td>

                                            <td class="table-first">Lembaga Ekolabel</td>
                                            <td class="table-second">:</td>
                                            <td class="table-third"><?php echo e($lembaga_ekolabel); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="table-first">Website Perusahaan</td>
                                            <td class="table-second">:</td>
                                            <td class="table-third"><?php echo e($website_perusahaan); ?>

                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="col-lg-6 col-md-6 col-12">
                                <table>
                                    <tbody>
                                        <tr>
                                            <td class="table-first">Kode Pos</td>
                                            <td class="table-second">:</td>
                                            <td class="table-third"><?php echo e($kodepos_perusahaan); ?></td>
                                        </tr>
                                        <tr>
                                            <td class="table-first">Fax</td>
                                            <td class="table-second">:</td>
                                            <td class="table-third"><?php echo e($fax_perusahaan); ?></td>
                                        </tr>
                                        <tr>
                                            <td class="table-first">Nomor SIUP</td>
                                            <td class="table-second">:</td>
                                            <td class="table-third"><?php echo e($no_siup); ?></td>
                                        </tr>
                                        <tr>
                                            <td class="table-first">Nomor NPWP</td>
                                            <td class="table-second">:</td>
                                            <td class="table-third"><?php echo e($no_npwp); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        
                        <table class="table table-sm table-borderless">
                            <tbody>
                                <tr>
                                    <td class="table-first">Nama</td>
                                    <td class="table-second">:</td>
                                    <td class="table-third"><?php echo e($nama1); ?></td>

                                    <td class="table-first">Jabatan</td>
                                    <td class="table-second">:</td>
                                    <td class="table-third"><?php echo e($jabatan1); ?></td>
                                </tr>
                                <tr>
                                    <td class="table-first">No Handphone</td>
                                    <td class="table-second">:</td>
                                    <td class="table-third"><?php echo e($no_hp1); ?></td>

                                    <td class="table-first">Email</td>
                                    <td class="table-second">:</td>
                                    <td class="table-third"><?php echo e($email1); ?></td>
                                </tr>
                                <tr>
                                    <td class="table-first">No Telp</td>
                                    <td class="table-second">:</td>
                                    <td class="table-third"><?php echo e($no_telp1); ?></td>

                                    <td class="table-first">Fax</td>
                                    <td class="table-second">:</td>
                                    <td class="table-third"><?php echo e($fax1); ?></td>
                                </tr>
                            </tbody>
                        </table>
                        
                        <table class="table table-sm table-borderless">
                            <tbody>
                                <tr>
                                    <?php if($nama2 != null): ?>
                                        <td class="table-first">Nama</td>
                                        <td class="table-second">:</td>
                                        <td class="table-third"><?php echo e($nama2); ?></td>
                                    <?php endif; ?>

                                    <?php if($jabatan2 != null): ?>
                                        <td class="table-first">Jabatan</td>
                                        <td class="table-second">:</td>
                                        <td class="table-third"><?php echo e($jabatan2); ?></td>
                                    <?php endif; ?>
                                </tr>
                                <tr>
                                    <?php if($no_hp2 != null): ?>
                                        <td class="table-first">No Handphone</td>
                                        <td class="table-second">:</td>
                                        <td class="table-third"><?php echo e($no_hp2); ?></td>
                                    <?php endif; ?>

                                    <?php if($email2 != null): ?>
                                        <td class="table-first">Email</td>
                                        <td class="table-second">:</td>
                                        <td class="table-third"><?php echo e($email2); ?></td>
                                    <?php endif; ?>
                                </tr>
                                <tr>
                                    <?php if($no_telp2 != null): ?>
                                        <td class="table-first">No Telp</td>
                                        <td class="table-second">:</td>
                                        <td class="table-third"><?php echo e($no_telp2); ?></td>
                                    <?php endif; ?>

                                    <?php if($fax2 != null): ?>
                                        <td class="table-first">Fax</td>
                                        <td class="table-second">:</td>
                                        <td class="table-third"><?php echo e($fax2); ?></td>
                                    <?php endif; ?>
                                </tr>
                            </tbody>
                        </table>

                        <h5>Informasi Fasilitas Produksi</h5>

                        <table class="table table-sm table-borderless">
                            <tbody>
                                <tr>
                                    <td class="table-first">Nama Pabrik</td>
                                    <td>:</td>
                                    <td><?php echo e($nama_fasilitas); ?></td>
                                </tr>
                                <tr>
                                    <td class="table-first">Alamat</td>
                                    <td>:</td>
                                    <td><?php echo e($alamat_fasilitas); ?></td>
                                </tr>
                                <tr>
                                    <td class="table-first">Kategori Produk</td>
                                    <td>:</td>
                                    <td><?php echo e($kategori_produk); ?></td>
                                </tr>
                            </tbody>
                        </table>
                        <table class="table table-sm table-borderless">
                            <tbody>
                                <tr>
                                    <td class="table-first">Email</td>
                                    <td class="table-second">:</td>
                                    <td class="table-third"><?php echo e($email_fasilitas); ?></td>

                                    <td class="table-first">Kode Pos</td>
                                    <td class="table-second">:</td>
                                    <td class="table-third"><?php echo e($kodepos_fasilitas); ?></td>
                                </tr>
                                <tr>
                                    <td class="table-first">No Telp</td>
                                    <td class="table-second">:</td>
                                    <td class="table-third"><?php echo e($no_telp_fasilitas); ?></td>

                                    <td class="table-first">Fax</td>
                                    <td class="table-second">:</td>
                                    <td class="table-third"><?php echo e($fax_fasilitas); ?></td>
                                </tr>
                            </tbody>
                        </table>
                        <table class="table table-sm table-borderless">
                            <tbody>
                                <tr>
                                    <td class="table-first">Nama</td>
                                    <td class="table-second">:</td>
                                    <td class="table-third"><?php echo e($nama3); ?></td>

                                    <td class="table-first">Jabatan</td>
                                    <td class="table-second">:</td>
                                    <td class="table-third"><?php echo e($jabatan3); ?></td>
                                </tr>
                                <tr>
                                    <td class="table-first">No Handphone</td>
                                    <td class="table-second">:</td>
                                    <td class="table-third"><?php echo e($no_hp3); ?></td>

                                    <td class="table-first">Email</td>
                                    <td class="table-second">:</td>
                                    <td class="table-third"><?php echo e($email3); ?></td>
                                </tr>
                                <tr>
                                    <td class="table-first">No Telp</td>
                                    <td class="table-second">:</td>
                                    <td class="table-third"><?php echo e($no_telp3); ?></td>

                                    <td class="table-first">Fax</td>
                                    <td class="table-second">:</td>
                                    <td class="table-third"><?php echo e($fax3); ?></td>
                                </tr>
                            </tbody>
                        </table>

                        <h5>Informasi Produk</h5>

                        <table class="table table-sm table-borderless">
                            <tbody>
                                <tr>
                                    <td class="table-first">Nama Produk</td>
                                    <td>:</td>
                                    <td><?php echo e($nama_produk); ?></td>
                                </tr>
                                <tr>
                                    <td class="table-first">Tipe / Model</td>
                                    <td>:</td>
                                    <td><?php echo e($tipe_model); ?></td>
                                </tr>
                            </tbody>
                        </table>
                        <table class="table table-sm table-borderless">
                            <tbody>
                                <tr>
                                    <td class="table-first">Ukuran</td>
                                    <td class="table-second">:</td>
                                    <td class="table-third"><?php echo e($ukuran); ?></td>

                                    <td class="table-first">Merk Dagang</td>
                                    <td class="table-second">:</td>
                                    <td class="table-third"><?php echo e($merk_dagang); ?></td>
                                </tr>
                            </tbody>
                        </table>
                        <table class="table table-sm table-borderless">
                            <tbody>
                                <tr>
                                    <td class="table-first">Deskripsi Produk</td>
                                    <td class="table-second">:</td>
                                    <td class="table-third"><?php echo e($deskripsi_produk); ?></td>
                                </tr>
                                <tr>
                                    <td class="table-first">Tipe Pengemasan dan Ukuran</td>
                                    <td class="table-second">:</td>
                                    <td class="table-third"><?php echo e($tipe_pengemasan); ?></td>
                                </tr>
                            </tbody>
                        </table>
                        <button class="btn btn-danger nextBtn prev-button pull-right" type="button"
                            wire:click="back(3)"><i class="fas fa-long-arrow-alt-left pr-2"></i> Back</button>
                        <button class="btn btn-primary nextBtn next-button pull-right" type="button"
                            wire:click="submitForm">Submit</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->startSection('js'); ?>
    <script>
        $(".nextBtn").click(function(e) {
            $(document).scrollTop(0)
        });

    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Projek\gpci\resources\views/livewire/wizard.blade.php ENDPATH**/ ?>