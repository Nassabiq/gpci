
<?php $__env->startSection('title', 'Input Angket Penilaian Sertifikasi'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Input Angket Penilaian</h2>
        <hr>
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <div class="col-6">
            <div class="card">
                <div class="card-body">
                    <form action="/penilaian/input-angket-penilaian/post" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">
                                <div class="form-group">
                                    <label>Dokumen Template</label>
                                    <br>
                                    <input type="file" name="angket_penilaian_doc">
                                    <br>
                                    <?php $__errorArgs = ['angket_penilaian_doc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </li>
                            <li class="list-group-item">
                                <div class="form-group">
                                    <label>Kategori</label>

                                    <select class="custom-select" name="category_id">
                                        <option value="">Kategori</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->categories); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </li>
                        </ul>
                    </form>
                </div>
            </div>
        </div>

        <?php $__errorArgs = ['category_id_edit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php $__errorArgs = ['angket_penilaian_doc_edit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <table class="table mt-4">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Kategori</th>
                    <th scope="col">File</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $no = 1;
                ?>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($no++); ?></th>
                        <td><?php echo e($kategori->categories); ?></td>
                        <td>
                            <?php if(isset($kategori->kategoriAngket->angket_penilaian_doc)): ?>
                                <?php echo e($kategori->kategoriAngket->angket_penilaian_doc); ?>

                            <?php else: ?>
                                <span class="badge badge-pill badge-danger">Data Tidak Ada</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if(isset($kategori->kategoriAngket->angket_penilaian_doc)): ?>
                                <div class="d-flex">
                                    <a href="<?php echo e(asset('storage/template_angket/' . $kategori->kategoriAngket->angket_penilaian_doc)); ?>"
                                        class="btn btn-sm btn-success" target="_blank  ">Preview</a>
                                    <button type="button" class="btn btn-sm btn-info ml-2" id="edit"
                                        data-id="<?php echo e($kategori->kategoriAngket->id); ?>"
                                        data-angket="<?php echo e($kategori->kategoriAngket->angket_penilaian_doc); ?>"
                                        data-kategori="<?php echo e($kategori->categories); ?>">
                                        Edit
                                    </button>
                                </div>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="modal fade" id="edit-modal" tabindex="-1">
            <div class="modal-dialog modal-lg">
                <form id="edit-form" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title"></h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item">
                                    <div class="form-group">
                                        <label>Dokumen Template</label>
                                        <br>
                                        <input type="file" name="angket_penilaian_doc_edit">
                                        <br>
                                    </div>
                                </li>
                                <li class="list-group-item">
                                    <div class="form-group">
                                        <label>Kategori</label>

                                        <select class="custom-select" name="category_id_edit">
                                            <option class="old" selected></option>
                                        </select>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save changes</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function() {
            /**
             * for showing edit item popup
             */

            $(document).on('click', "#edit", function() {
                let id = $(this).data('id');
                let angket = $(this).data('angket');
                let kategori = $(this).data('kategori');
                $('#edit-modal').modal('show');

                var title = $('.modal-title');
                title.html('Ubah Dokumen ' + kategori);

                var oldkategori = $('.old');
                oldkategori.attr('value', id).html(kategori);

                var form = $('#edit-form');
                form.attr('action', '/penilaian/edit-angket-penilaian/edit/' + id)
            })
        })

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projek\gpci\resources\views/client/angket-penilaian.blade.php ENDPATH**/ ?>