<div>
    <div class="card card-outline card-teal p-4">
        <div class="card-body setup-content">

            <div class="col-md-12">
                <h3>Informasi Fasilitas Produksi</h3>
                <hr>
                <div class="form-group">
                    <label for="exampleFormControlSelect1">Nama Perusahaan</label>
                    <select class="form-control" wire:model="company_id">
                        <option value="">Select Company</option>
                        <?php $__currentLoopData = $company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama_perusahaan); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                
                <div class="form-group row">
                    <label>Nama Pabrik:</label>
                    <input type="text" wire:model="nama_fasilitas" class="form-control form-control-sm"
                        id="nama_fasilitas" placeholder="Nama Pabrik ...">
                    <?php $__errorArgs = ['nama_fasilitas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="form-group row">
                    <label>Email:</label>
                    <input type="email" wire:model="email_fasilitas" class="form-control form-control-sm"
                        id="email_fasilitas" placeholder="Email Pabrik ...">
                    <?php $__errorArgs = ['email_fasilitas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="form-group row">
                    <label>Alamat Pabrik:</label>
                    <input type="text" wire:model="alamat_fasilitas" class="form-control form-control-sm"
                        id="alamat_fasilitas" placeholder="Alamat Pabrik ...">
                    <?php $__errorArgs = ['alamat_fasilitas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="row">
                    <div class="form-group col-lg-2 col-md-2 col-sm-12 pl-0">
                        <label for="title">Kode Pos:</label>
                        <input type="text" wire:model="kodepos_fasilitas" class="form-control form-control-sm"
                            id="kodepos_fasilitas" placeholder="Kode Pos...">
                        <?php $__errorArgs = ['kodepos_fasilitas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group col-5 col-md-5 col-sm-6 col-6 pl-0">
                        <label for="title">No Telp:</label>
                        <input type="text" wire:model="no_telp_fasilitas" class="form-control form-control-sm"
                            id="no_telp_fasilitas" placeholder="No. Telp ...">
                        <?php $__errorArgs = ['no_telp_fasilitas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group col-5 col-md-5 col-sm-6 col-6 pl-0">
                        <label for="title">Fax:</label>
                        <input type="text" wire:model="fax_fasilitas" class="form-control form-control-sm"
                            id="fax_fasilitas" placeholder="Fax ...">
                        <?php $__errorArgs = ['fax_fasilitas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                
                <div class="form-group row">
                    <label class="col-12 px-0">Contact Person:</label> <br>
                    
                    <div class="cp col-lg-6 col-md-12 col-12 pl-0">
                        <input type="text" wire:model="nama3" class="form-control form-control-sm" id="nama3"
                            placeholder="Nama ...">
                        <?php $__errorArgs = ['nama3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="cp col-lg-6 col-md-12 col-12 px-0">
                        <input type="text" wire:model="jabatan3" class="form-control form-control-sm" id="jabatan3"
                            placeholder="Jabatan...">
                        <?php $__errorArgs = ['jabatan3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="form-group row">
                    
                    <div class="cp col-lg-6 col-md-12 col-12 pl-0">
                        <input type="text" wire:model="no_hp3" class="form-control form-control-sm" id="no_hp3"
                            placeholder="No Handphone (WA) ...">
                        <?php $__errorArgs = ['no_hp3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="cp col-lg-6 col-md-12 col-12 px-0">
                        <input type="email" wire:model="email3" class="form-control form-control-sm" id="email3"
                            placeholder="Email...">
                        <?php $__errorArgs = ['email3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="form-group row">
                    
                    <div class="cp col-lg-6 col-md-12 col-12 pl-0">
                        <input type="text" wire:model="no_telp3" class="form-control form-control-sm" id="no_telp3"
                            placeholder="No Telp ...">
                        <?php $__errorArgs = ['no_telp3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="cp col-lg-6 col-md-12 col-12 px-0">
                        <input type="text" wire:model="fax3" class="form-control form-control-sm" id="fax3"
                            placeholder="No Fax...">
                        <?php $__errorArgs = ['fax3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <button class="btn btn-primary nextBtn pull-right next-button" type="submit"
                    wire:click="uploadPlant">Upload</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Projek\gpci\resources\views/livewire/import-plant.blade.php ENDPATH**/ ?>