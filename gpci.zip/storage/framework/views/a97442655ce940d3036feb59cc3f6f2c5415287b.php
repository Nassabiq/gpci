
<?php $__env->startSection('title', 'Import Data'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Import Data</h2>
        <hr>
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-3">
                <div class="list-group" id="list-tab" role="tablist">
                    <a class="list-group-item list-group-item-action active" id="list-home-list" data-toggle="list"
                        href="#list-home" role="tab" aria-controls="home">Import Data Perusahaan</a>
                    <a class="list-group-item list-group-item-action" id="list-profile-list" data-toggle="list"
                        href="#list-profile" role="tab" aria-controls="profile">Import Data Plant</a>
                    <a class="list-group-item list-group-item-action" id="list-messages-list" data-toggle="list"
                        href="#list-messages" role="tab" aria-controls="messages">Import Data Produk</a>
                </div>
            </div>
            <div class="col-9">
                <div class="tab-content" id="nav-tabContent">
                    <div class="tab-pane fade show active" id="list-home" role="tabpanel" aria-labelledby="list-home-list">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('import-perusahaan')->html();
} elseif ($_instance->childHasBeenRendered('PdTaykJ')) {
    $componentId = $_instance->getRenderedChildComponentId('PdTaykJ');
    $componentTag = $_instance->getRenderedChildComponentTagName('PdTaykJ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('PdTaykJ');
} else {
    $response = \Livewire\Livewire::mount('import-perusahaan');
    $html = $response->html();
    $_instance->logRenderedChild('PdTaykJ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                    <div class="tab-pane fade" id="list-profile" role="tabpanel" aria-labelledby="list-profile-list">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('import-plant')->html();
} elseif ($_instance->childHasBeenRendered('FR6xddo')) {
    $componentId = $_instance->getRenderedChildComponentId('FR6xddo');
    $componentTag = $_instance->getRenderedChildComponentTagName('FR6xddo');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('FR6xddo');
} else {
    $response = \Livewire\Livewire::mount('import-plant');
    $html = $response->html();
    $_instance->logRenderedChild('FR6xddo', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                    <div class="tab-pane fade" id="list-messages" role="tabpanel" aria-labelledby="list-messages-list">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('import-produk')->html();
} elseif ($_instance->childHasBeenRendered('13QLG4i')) {
    $componentId = $_instance->getRenderedChildComponentId('13QLG4i');
    $componentTag = $_instance->getRenderedChildComponentTagName('13QLG4i');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('13QLG4i');
} else {
    $response = \Livewire\Livewire::mount('import-produk');
    $html = $response->html();
    $_instance->logRenderedChild('13QLG4i', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projek\gpci\resources\views/client/import-data.blade.php ENDPATH**/ ?>