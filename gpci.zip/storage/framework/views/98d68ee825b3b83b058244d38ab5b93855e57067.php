
<?php $__env->startSection('title', 'Add Kategori Produk'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="d-flex justify-content-between">
            <h2>Kategori Produk</h2>
            <button class="btn btn-sm btn-primary addKategori" data-title="Tambah Kategori">Tambah Kategori</button>
        </div>
        <hr>
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success" role="alert">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <?php $__errorArgs = ['categories'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <table class="table">
            <thead class="thead-light">
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Nama Kategori</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $no = 1;
                ?>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($no++); ?></th>
                        <td><?php echo e($category->categories); ?></td>
                        <td>
                            <div class="d-flex">
                                <button class="btn btn-sm btn-success editKategori" data-title="Edit Kategori"
                                    data-id="<?php echo e($category->id); ?>" data-value="<?php echo e($category->categories); ?>">Edit</button>
                                <button class="btn btn-sm btn-danger ml-2 deleteKategori"
                                    data-id="<?php echo e($category->id); ?>">Delete</button>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="d-flex justify-content-center">
            <?php echo e($categories->links()); ?>

        </div>

    </div>

    <div class="modal fade" tabindex="-1">
        <div class="modal-dialog">
            <form method="post" id="form">
                <?php echo csrf_field(); ?>
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="title"></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Nama Kategori</label>
                            <input type="text" class="form-control" name="categories" id="input">

                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="modal fade" tabindex="-1" id="deleteKategori">
        <div class="modal-dialog modal-dialog-centered">
            <form method="post" id="form-delete">
                <?php echo csrf_field(); ?>
                <div class="modal-content">
                    <div class="modal-body">
                        Apakah anda ingin menghapus data ini?
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Delete</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).on('click', '.addKategori', function(event) {
            event.preventDefault();
            let title = $(this).data('title');
            let form = $('#form');
            $('.modal').modal('show');

            form.attr('action', '/import/kategori-produk/post');
            $('#title').html(title);

            // /import/kategori-produk/post
        });

        $(document).on('click', '.editKategori', function(event) {
            event.preventDefault();
            let id = $(this).data('id');
            let title = $(this).data('title');
            let value = $(this).data('value');
            let form = $('#form');
            let input = $('#input');
            $('.modal').modal('show');

            form.attr('action', '/import/kategori-produk/' + id + '/edit');
            $('#title').html(title);
            input.val(value);

            // /import/kategori-produk/post
        });
        $(document).on('click', '.deleteKategori', function(event) {
            event.preventDefault();
            let id = $(this).data('id');
            let form = $('#form-delete');
            $('#deleteKategori').modal('show');

            form.attr('action', '/import/kategori-produk/' + id + '/delete');

            // /import/kategori-produk/post
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projek\gpci\resources\views/client/add-kategori-produk.blade.php ENDPATH**/ ?>