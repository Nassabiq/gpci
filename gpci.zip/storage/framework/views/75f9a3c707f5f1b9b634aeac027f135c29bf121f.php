<div>
    <div class="card card-outline card-teal p-4">
        <div class="card-body setup-content">
            
            
            <div class="col-md-12">
                <h3>Informasi Produk</h3>
                <hr>
                <div class="form-group">
                    <label for="exampleFormControlSelect1">Nama Plant</label>
                    <select class="form-control" wire:model="plant_id">
                        <option value="">Select Plant</option>
                        <?php $__currentLoopData = $plant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama_fasilitas); ?> -
                                <?php echo e($item->perusahaan->nama_perusahaan); ?></option>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                
                <div class="form-group row">
                    <label>Nama Produk:</label>
                    <input type="text" wire:model="nama_produk" class="form-control form-control-sm" id="nama_produk"
                        placeholder="Nama Produk ...">
                    <?php $__errorArgs = ['nama_produk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group row">
                    <label>Tipe / Model:</label>
                    <input type="text" wire:model="tipe_model" class="form-control form-control-sm" id="tipe_model"
                        placeholder="Tipe / Model ...">
                    <?php $__errorArgs = ['tipe_model'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group row">
                    
                    <div class="cp col-lg-3 col-md-12 col-12 pl-0">
                        <label>Ukuran</label>
                        <input type="text" wire:model="ukuran" class="form-control form-control-sm" id="ukuran"
                            placeholder="Ukuran...">
                        <?php $__errorArgs = ['ukuran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="cp col-lg-9 col-md-12 col-12 px-0">
                        <label>Merk Dagang:</label>
                        <input type="text" wire:model="merk_dagang" class="form-control form-control-sm"
                            id="merk_dagang" placeholder="Merk Dagang...">
                        <?php $__errorArgs = ['merk_dagang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                
                <div class="form-group row">
                    <label>Deskripsi Produk:</label>
                    <textarea class="form-control" id="deskripsi" rows="3" wire:model="deskripsi_produk"></textarea>
                    <?php $__errorArgs = ['deskripsi_produk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="form-group row">
                    <label>Produk yang akan disertifikasi:</label>
                    <select class="custom-select custom-select-sm" wire:model="kategori_produk" id="inputGroupSelect02">
                        <option value="">Choose...</option>
                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>">
                                <?php echo e($item->categories); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                
                <div class="form-group row">
                    <label>Jenis Sertifikasi :</label>
                    <select class="form-control form-control-sm" wire:model="jenis_sertifikasi">
                        <option>Jenis Sertifikasi</option>
                        <option value="1">Pengajuan Baru</option>
                        <option value="2">Perpanjangan</option>
                    </select>
                    <?php $__errorArgs = ['jenis_sertifikasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <label>Foto Produk:</label>
                <div class="input-group mb-3 mx-0">
                    <div class="custom-file">
                        <input type="file" class="custom-file-input"  name="foto_produk[]"
                            accept="image/*" wire:model="foto_produk" multiple id="photoproduk">
                        <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                    </div>
                </div>
                <?php $__currentLoopData = $foto_produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card d-inline-block">
                        <?php if($photos): ?>
                            <div class="card-body">
                                <img width="150px" height="150px" style="object-fit: cover"
                                    src="<?php echo e($photos->temporaryUrl()); ?>">
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__errorArgs = ['foto_produk.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-group row">
                    <label>Tipe Pengemasan dan Ukuran:</label>
                    <input type="text" wire:model="tipe_pengemasan" class="form-control form-control-sm"
                        id="tipe_pengemasan" placeholder="Tipe Pengemasan dan Ukuran ...">
                    <?php $__errorArgs = ['tipe_pengemasan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>


                <button class="btn btn-primary nextBtn next-button pull-right" wire:click="uploadProduk"
                    type="button">Submit</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Projek\gpci\resources\views/livewire/import-produk.blade.php ENDPATH**/ ?>