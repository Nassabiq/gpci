
<?php $__env->startSection('title', 'Input Data Sertifikasi'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('wizard-plant')->html();
} elseif ($_instance->childHasBeenRendered('KhZF8RY')) {
    $componentId = $_instance->getRenderedChildComponentId('KhZF8RY');
    $componentTag = $_instance->getRenderedChildComponentTagName('KhZF8RY');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('KhZF8RY');
} else {
    $response = \Livewire\Livewire::mount('wizard-plant');
    $html = $response->html();
    $_instance->logRenderedChild('KhZF8RY', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projek\gpci\resources\views/client/add-plant.blade.php ENDPATH**/ ?>