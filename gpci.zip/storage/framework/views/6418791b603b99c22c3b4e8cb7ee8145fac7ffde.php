
<?php $__env->startSection('title', 'Data Sertifikasi'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Data Sertifikasi</h2>
        <div class="wrap-table mt-4">
            <?php if(!$company): ?>
                <div class="jumbotron jumbotron-fluid">
                    <div class="container">
                        <p class="lead text-center">Belum Ada Data Sertifikasi yang Didaftarkan</p>
                    </div>
                </div>
            <?php else: ?>
                <table class="table table-sm">
                    <tbody>
                        <tr>
                            <th class="table-first">Nama Perusahaan</th>
                            <td class="table-second">:</td>
                            <td><?php echo e($company->nama_perusahaan); ?></td>
                        </tr>
                        <tr>
                            <th class="table-first">Alamat</th>
                            <td class="table-second">:</td>
                            <td><?php echo e($company->alamat_perusahaan); ?></td>
                        </tr>
                        <tr>
                            <th class="table-first">Email</th>
                            <td class="table-second">:</td>
                            <td><?php echo e($company->email_perusahaan); ?></td>
                        </tr>
                    </tbody>
                </table>
                <?php
                    $contact = json_decode($company->contact);
                ?>
                <div class="d-flex justify-content-center">
                    <div class="spinner-border text-success" id="spin" role="status">
                        <span class="sr-only">Loading...</span>
                    </div>
                </div>
                <table class="table table-sm" id="nextdesc">
                    <tbody>
                        <tr>
                            <th class="table-first">No Telp</th>
                            <td class="table-second">:</td>
                            <td class="table-third"><?php echo e($company->no_telp_perusahaan); ?></td>

                            <th class="table-first">Kode Pos</th>
                            <td class="table-second">:</td>
                            <td class="table-third"><?php echo e($company->kodepos_perusahaan); ?> </td>
                        </tr>
                        <tr>
                            <th class="table-first">No Fax</th>
                            <td class="table-second">:</td>
                            <td class="table-third">
                                <?php if($company->fax_perusahaan): ?>
                                    <?php echo e($company->fax_perusahaan); ?>

                                <?php endif; ?>
                            </td>

                            <th class="table-first">No Akta Notaris</th>
                            <td class="table-second">:</td>
                            <td class="table-third"><?php echo e($company->no_akta_notaris); ?> </td>
                        </tr>
                        <tr>
                            <th class="table-first">No SIUP</th>
                            <td class="table-second">:</td>
                            <td class="table-third"><?php echo e($company->no_siup); ?></td>

                            <th class="table-first">No TDP</th>
                            <td class="table-second">:</td>
                            <td class="table-third"><?php echo e($company->no_tdp); ?> </td>
                        </tr>
                        <tr>
                            <th class="table-first">No NPWP</th>
                            <td class="table-second">:</td>
                            <td class="table-third"><?php echo e($company->no_npwp); ?></td>

                            <th class="table-first">No API</th>
                            <td class="table-second">:</td>
                            <td class="table-third"><?php echo e($company->no_api); ?> </td>
                        </tr>
                        <tr>
                            <th class="table-first">Lembaga Ekolabel</th>
                            <td class="table-second">:</td>
                            <td class="table-third">
                                <?php if($company->lembaga_ekolabel): ?>
                                    <?php echo e($company->fax_perusahaan); ?>

                                <?php endif; ?>
                            </td>

                            <th class="table-first">Website Perusahaan</th>
                            <td class="table-second">:</td>
                            <td class="table-third"><?php echo e($company->website_perusahaan); ?> </td>
                        </tr>
                        <tr>
                            <td class="table-first">Contact Person: </td>
                        </tr>
                        <tr>
                            <th class="table-first">Nama</th>
                            <td class="table-second">:</td>
                            <td class="table-third">
                                <?php echo e($contact->cp_1->nama); ?>

                            </td>

                            <th class="table-first">Jabatan</th>
                            <td class="table-second">:</td>
                            <td class="table-third"><?php echo e($contact->cp_1->jabatan); ?> </td>
                        </tr>
                        <tr>
                            <th class="table-first">No Telp</th>
                            <td class="table-second">:</td>
                            <td class="table-third">
                                <?php echo e($contact->cp_1->no_telp); ?>

                            </td>

                            <th class="table-first">Email</th>
                            <td class="table-second">:</td>
                            <td class="table-third"><?php echo e($contact->cp_1->email); ?> </td>
                        </tr>
                        <tr>
                            <th class="table-first">No Handphone</th>
                            <td class="table-second">:</td>
                            <td class="table-third">
                                <?php echo e($contact->cp_1->no_hp); ?>

                            </td>

                            <th class="table-first">No Fax</th>
                            <td class="table-second">:</td>
                            <td class="table-third"><?php echo e($contact->cp_1->fax); ?> </td>
                        </tr>
                        <?php if($contact->cp_2->nama2): ?>
                            <tr>
                                <td class="table-first">Contact Person 2: </td>
                            </tr>

                            <tr>
                                <th class="table-first">Nama</th>
                                <td class="table-second">:</td>
                                <td class="table-third">
                                    <?php echo e($contact->cp_2->nama2); ?>

                                </td>

                                <?php if($contact->cp_2->jabatan2): ?>
                                    <th class="table-first">Jabatan</th>
                                    <td class="table-second">:</td>
                                    <td class="table-third"><?php echo e($contact->cp_2->jabatan2); ?> </td>
                                <?php endif; ?>
                        <?php endif; ?>
                        </tr>
                        <tr>
                            <?php if($contact->cp_2->no_telp2): ?>
                                <th class="table-first">No Telp</th>
                                <td class="table-second">:</td>
                                <td class="table-third">
                                    <?php echo e($contact->cp_2->no_telp2); ?>

                                </td>
                            <?php endif; ?>

                            <?php if($contact->cp_2->email2): ?>
                                <th class="table-first">Email</th>
                                <td class="table-second">:</td>
                                <td class="table-third"><?php echo e($contact->cp_2->email2); ?> </td>
                            <?php endif; ?>
                        </tr>
                        <tr>
                            <?php if($contact->cp_2->no_hp2): ?>
                                <th class="table-first">No Handphone</th>
                                <td class="table-second">:</td>
                                <td class="table-third">
                                    <?php echo e($contact->cp_2->no_hp2); ?>

                                </td>
                            <?php endif; ?>

                            <?php if($contact->cp_2->fax2): ?>
                                <th class="table-first">No Fax</th>
                                <td class="table-second">:</td>
                                <td class="table-third"><?php echo e($contact->cp_2->fax2); ?> </td>
                            <?php endif; ?>
                        </tr>
                    </tbody>

                </table>
                <div class="row justify-content-between mt-3 pb-3">
                    <div class="col-3">
                        <button type="button" class="btn btn-sm btn-primary" id="showDesc" onclick="showDesc(this)">Data
                            Lengkap
                            <i class="fas fa-chevron-down showdesc pl-2" id="fa-icon"></i></button>
                    </div>
                    <div class="col-2">
                        <select class="custom-select" onchange="showData(this)">
                            <option value="1">Produk</option>
                            <option value="2">Fasilitas Produksi</option>
                        </select>
                    </div>
                </div>
                <div id="dataProduk">
                    <table class="table table-bordered w-100">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col">Nama Produk</th>
                                <th scope="col">Deskripsi</th>
                                <th scope="col">Pabrik</th>
                                <th scope="col">Status</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $no = 1;
                            ?>
                            <?php $__currentLoopData = $company->factories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $item->produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($no++); ?></th>
                                        <td><?php echo e($produk->nama_produk); ?></td>
                                        <td><?php echo e($produk->deskripsi_produk); ?></td>
                                        <td><?php echo e($item->nama_fasilitas); ?></td>
                                        <td>
                                            <?php if($produk->status == 1): ?>
                                                <span class="badge badge-pill badge-danger">Belum Diverifikasi</span>
                                            <?php elseif($produk->status == 2): ?>
                                                <span class="badge badge-pill badge-warning">Sedang Diverifikasi</span>
                                            <?php elseif($produk->status == 3): ?>
                                                <span class="badge badge-pill badge-success">Terverifikasi</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <button type="button" class="btn btn-sm btn-primary" data-toggle="collapse"
                                                data-target="#detail-<?php echo e($produk->id); ?>">
                                                <i class="fas fa-fw fa-info-circle"></i>
                                                Detail
                                            </button>
                                            <?php if($produk->status == 3): ?>
                                                <a href="/cetak-pdf/<?php echo e($produk->id); ?>" target="_blank"
                                                    class="btn btn-sm btn-warning">
                                                    Cetak Sertifikat
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="6" class="collapse" id="detail-<?php echo e($produk->id); ?>">
                                            <label>Foto Produk</label>
                                            <div class="d-flex">
                                                <div class="col-lg-6 col-md-12">
                                                    <?php
                                                        $images = json_decode($produk->foto_produk);
                                                    ?>
                                                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <a href="#" class="imagemodal">
                                                            <img src="<?php echo e(asset('storage/foto_produk/' . $company->nama_perusahaan . '/' . $image)); ?>"
                                                                alt="<?php echo e($produk->nama_produk); ?>" width="200px"
                                                                height="200px" class="border border-primary rounded mx-2">
                                                        </a>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                                <div class="col-lg-6 col-md-12">
                                                    <ul class="list-group">
                                                        <li class="list-group-item">
                                                            <b>Jenis Sertifikasi</b> :
                                                            <?php echo e($produk->jenis_sertifikasi == 1 ? 'Pengajuan Baru' : 'Perpanjangan'); ?>

                                                        </li>
                                                        <li class="list-group-item">
                                                            <b>Tipe Model</b> : <?php echo e($produk->tipe_model); ?>

                                                        </li>
                                                        <li class="list-group-item">
                                                            <b>Merk Dagang</b> : <?php echo e($produk->merk_dagang); ?>

                                                        </li>
                                                        <li class="list-group-item">
                                                            <b>Tipe Pengemasan</b> : <?php echo e($produk->tipe_pengemasan); ?>

                                                        </li>
                                                        <li class="list-group-item">
                                                            <b>Ukuran</b> : <?php echo e($produk->ukuran); ?>

                                                        </li>
                                                        <li class="list-group-item">
                                                            <b>Tanggal Pendaftaran</b> :
                                                            <?php echo e(\Carbon\Carbon::parse($produk->tgl_pendaftaran)->locale('id')->isoFormat('dddd, D MMMM Y')); ?>

                                                        </li>
                                                        <?php if($produk->status == 3): ?>
                                                            <li class="list-group-item">
                                                                <b>Masa Berlaku s/d</b> :
                                                                <?php echo e(\Carbon\Carbon::parse($produk->tgl_masa_berlaku)->locale('id')->isoFormat('dddd, D MMMM Y')); ?>

                                                            </li>
                                                        <?php endif; ?>
                                                    </ul>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <div class="modal fade" id="imagepreview" tabindex="-1">
                                        <div class="modal-dialog modal-dialog-centered modal-xl">
                                            <div class="modal-content">
                                                <div class="modal-body">
                                                    <img src="" id="image-full" style="width: 100%;">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div id="dataPabrik">
                    <table class="table table-bordered w-100">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col">Nama Fasilitas</th>
                                <th scope="col">No. Telp</th>
                                <th scope="col">Email</th>
                                <th scope="col">Kode Pos</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php
                                $no2 = 1;
                            ?>
                            <?php $__currentLoopData = $company->factories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pabrik): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($no2++); ?></th>
                                    <td><?php echo e($pabrik->nama_fasilitas); ?></td>
                                    <td><?php echo e($pabrik->no_telp_fasilitas); ?></td>
                                    <td><?php echo e($pabrik->email_fasilitas); ?></td>
                                    <td><?php echo e($pabrik->kodepos_fasilitas); ?></td>
                                    <td>
                                        <button type="button" class="btn text-primary"><abbr title="Detail Produk">
                                                <i class="fas fa-fw fa-info-circle"></i></abbr></button>

                                        <button type="button" class="border-0 bg-transparent text-danger"
                                            data-toggle="modal" data-target="#deleteModal"><abbr title="Delete FAQ">
                                                <i class="fas fa-fw fa-trash"></i>
                                        </button>
                                    </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            </tr>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(function() {
            $('.imagemodal').on('click', function() {
                $('#image-full').attr('src', $(this).find('img').attr('src'));
                $('#imagepreview').modal('show');
            });
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projek\gpci\resources\views/client/data-sertifikasi.blade.php ENDPATH**/ ?>