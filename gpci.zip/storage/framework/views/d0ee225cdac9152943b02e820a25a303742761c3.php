


<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('beautymail::templates.sunny.heading' , [
    'heading' => 'Thank You for Submitting Your Application Form',
    'level' => 'h2',
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('beautymail::templates.sunny.contentStart', ['logo'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div style="text-align: center">
        <p>Terima kasih atas pendaftarannya dari <?php echo e($nama); ?>. Formulir pendaftaran sertifikasi Green Label
            Indonesia
            (GLI) telah kami terima dengan baik.</p>
        <p>
            Selanjutnya adalah input checklist dokumen, mohon dipersiapkan copy dokumen pelengkap sesuai
            checklist tersebut dan di-input kembali pada Sistem sertifikasi Green Label Indonesia <a
                href="google.com">disini</a>. <br>
        </p>
        <p style="margin-top: 10px">
            Demikian informasi dari kami. Terima kasih atas perhatiannya.
        </p>
    </div>

    <?php echo $__env->make('beautymail::templates.sunny.contentEnd', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('beautymail::templates.sunny', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projek\gpci\resources\views/email.blade.php ENDPATH**/ ?>