
<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php $__currentLoopData = Auth::user()->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php switch($role->name):
                case ('client'): ?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dashboard.client-dashboard')->html();
} elseif ($_instance->childHasBeenRendered('dYaDsi3')) {
    $componentId = $_instance->getRenderedChildComponentId('dYaDsi3');
    $componentTag = $_instance->getRenderedChildComponentTagName('dYaDsi3');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('dYaDsi3');
} else {
    $response = \Livewire\Livewire::mount('dashboard.client-dashboard');
    $html = $response->html();
    $_instance->logRenderedChild('dYaDsi3', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                <?php break; ?>
                <?php case ('verifikator'): ?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dashboard.verifikator-dashboard')->html();
} elseif ($_instance->childHasBeenRendered('nngRM59')) {
    $componentId = $_instance->getRenderedChildComponentId('nngRM59');
    $componentTag = $_instance->getRenderedChildComponentTagName('nngRM59');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('nngRM59');
} else {
    $response = \Livewire\Livewire::mount('dashboard.verifikator-dashboard');
    $html = $response->html();
    $_instance->logRenderedChild('nngRM59', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                <?php break; ?>
                <?php case ('admin'): ?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dashboard.admin-dashboard')->html();
} elseif ($_instance->childHasBeenRendered('9jlsOEa')) {
    $componentId = $_instance->getRenderedChildComponentId('9jlsOEa');
    $componentTag = $_instance->getRenderedChildComponentTagName('9jlsOEa');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('9jlsOEa');
} else {
    $response = \Livewire\Livewire::mount('dashboard.admin-dashboard');
    $html = $response->html();
    $_instance->logRenderedChild('9jlsOEa', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                <?php break; ?>
                <?php default: ?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dashboard.admin-dashboard')->html();
} elseif ($_instance->childHasBeenRendered('1h90VFy')) {
    $componentId = $_instance->getRenderedChildComponentId('1h90VFy');
    $componentTag = $_instance->getRenderedChildComponentTagName('1h90VFy');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('1h90VFy');
} else {
    $response = \Livewire\Livewire::mount('dashboard.admin-dashboard');
    $html = $response->html();
    $_instance->logRenderedChild('1h90VFy', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <?php endswitch; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projek\gpci\resources\views/client/dashboard.blade.php ENDPATH**/ ?>