
<?php $__env->startSection('title', 'Input Data Sertifikasi'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        
        <h2>Data Sertifikasi</h2>
        <hr>

        <table class="table">
            <thead class="thead-light">
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Nama Perusahaan</th>
                    <th scope="col">Alamat</th>
                    <th scope="col">Email</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $no = 1;
                ?>
                <?php $__currentLoopData = $company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($no++); ?></th>
                        <td><?php echo e($item->nama_perusahaan); ?></td>
                        <td><?php echo e($item->alamat_perusahaan); ?></td>
                        <td><?php echo e($item->email_perusahaan); ?></td>
                        <td>
                            <a href="<?php echo e(url('/sertifikasi/data-sertifikasi/' . $item->id)); ?>"
                                class="btn btn-sm btn-primary">Details</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="d-flex justify-content-center">
            <?php echo e($company->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projek\gpci\resources\views/client/all-data-sertifikasi.blade.php ENDPATH**/ ?>