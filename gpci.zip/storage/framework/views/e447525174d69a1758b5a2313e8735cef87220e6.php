<div>
    
    <div class="container">
        <h2>Approve Dokumen</h2>
        <hr>
        <label for="company" class="col-1">Perusahaan</label>
        <div class="d-flex">
            <div class="col-3">
                <select class="custom-select" id="company" wire:model="selectedCompany">
                    <option value="" selected>Perusahaan</option>
                    <?php if($companies): ?>
                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($company->id); ?>">
                                <?php echo e($company->nama_perusahaan); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
            </div>

            <?php if(!is_null($selectedCompany)): ?>
                <label for="factory" class="col-1">Factory</label>
                <div class="col-3">
                    <select class="form-control" wire:model="selectedFactory">
                        <option value="" selected>Factory</option>
                        <?php $__currentLoopData = $factories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $factory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($factory->id); ?>"><?php echo e($factory->nama_fasilitas); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            <?php endif; ?>
            <?php if(!is_null($selectedFactory)): ?>
                <label for="products" class="col-1">Products</label>
                <div class="col-3">
                    <select class="form-control" wire:model="selectedProduct">
                        <option value="0">Product</option>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($product->id); ?>"><?php echo e($product->nama_produk); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            <?php endif; ?>
        </div>
        
        <?php if($selectedProduct != 0): ?>
            <table class="table mt-4">
                <thead class="thead-light">
                    <tr>
                        <th scope="col">Nama Dokumen</th>
                        <th scope="col">File</th>
                        <th scope="col">Action</th>
                        <th scope="col">Status</th>
                        <th scope="col">Keterangan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $document->document; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($doc->nama_dokumen); ?>

                            </td>
                            <?php if($doc->pivot->nama_dokumen): ?>
                                <td>
                                    <?php echo e($doc->pivot->nama_dokumen); ?>

                                </td>
                                <td class="d-flex">
                                    <a href="<?php echo e(asset('storage/checklist-dokumen/' . $this->perusahaan->nama_perusahaan . '/' . $doc->pivot->nama_dokumen)); ?>"
                                        class="btn btn-sm btn-primary" target="_blank">Preview</a>

                                    <button class="btn btn-sm btn-success ml-2 approve" data-toggle="modal"
                                        data-target="#approve-<?php echo e($doc->id); ?>">Approve</button>

                                    
                                    <div class="modal fade" id="approve-<?php echo e($doc->id); ?>" tabindex="-1">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content">
                                                <div class="modal-body">
                                                    <h5>Approve Dokumen ?</h5>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-dismiss="modal">No</button>
                                                    <button type="button" wire:click="approve(<?php echo e($doc->id); ?>)"
                                                        class="btn btn-primary">Yes</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <?php switch($doc->pivot->status):
                                        case (0): ?>
                                        <span class="badge badge-pill badge-secondary">kosong</span>
                                        <?php break; ?>
                                        <?php case (1): ?>
                                        <span class="badge badge-pill badge-danger">Belum diapprove</span>
                                        <?php break; ?>
                                        <?php case (2): ?>
                                        <span class="badge badge-pill badge-success">Approved</span>
                                        <?php break; ?>
                                        <?php default: ?>
                                    <?php endswitch; ?>
                                </td>
                                <td>
                                    <?php if($doc->pivot->keterangan): ?>
                                        <?php echo e($doc->pivot->keterangan); ?>

                                    <?php else: ?>
                                        <button class="btn btn-sm btn-info ml-2" data-toggle="modal"
                                            data-target="#keterangan<?php echo e($doc->id); ?>">Keterangan</button>

                                        
                                        <div class="modal fade" tabindex="-1" id="keterangan<?php echo e($doc->id); ?>"
                                            wire:ignore.self>
                                            <div class="modal-dialog modal-dialog-centered">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Tambah Keterangan</h5>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                            <input type="name" wire:model="keterangan"
                                                                class="form-control"
                                                                placeholder="Keterangan Dokumen...">
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-dismiss="modal">Tutup</button>
                                                        <button type="button"
                                                            wire:click="addKeterangan(<?php echo e($doc->id); ?>)"
                                                            class="btn btn-primary">Simpan</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </td>
                            <?php else: ?>
                                <td>
                                    <span class="badge badge-pill badge-warning">Belum Ada Dokumen</span>
                                </td>
                            <?php endif; ?>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<?php $__env->startSection('js'); ?>
    <script>
        // window.onbeforeunload = function() {
        //     return "Data will be lost if you leave the page, are you sure?";
        // };

        window.livewire.on('hideModal', () => {
            $('.modal').modal('hide');
            $('.modal-backdrop').remove();
        });

        // $(document).on('click', '.showmodal', function() {
        //     let name = $(this).data('name');
        //     let id = $(this).data('id');
        //     $('.modal').modal('show');
        //     let doc = $('#submit');
        //     doc.attr("wire:click", 'approve' + name + '(' + id + ')');
        //     console.log(doc);
        // });

    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Projek\gpci\resources\views/livewire/approve-dokumen.blade.php ENDPATH**/ ?>