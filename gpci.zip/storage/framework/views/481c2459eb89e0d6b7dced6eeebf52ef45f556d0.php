
<?php $__env->startSection('title', 'Import Checklist Dokumen'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('checklist-dokumen')->html();
} elseif ($_instance->childHasBeenRendered('FP6tkgU')) {
    $componentId = $_instance->getRenderedChildComponentId('FP6tkgU');
    $componentTag = $_instance->getRenderedChildComponentTagName('FP6tkgU');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('FP6tkgU');
} else {
    $response = \Livewire\Livewire::mount('checklist-dokumen');
    $html = $response->html();
    $_instance->logRenderedChild('FP6tkgU', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projek\gpci\resources\views/client/import-checklist-dokumen.blade.php ENDPATH**/ ?>