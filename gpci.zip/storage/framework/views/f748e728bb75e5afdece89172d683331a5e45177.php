
<?php $__env->startSection('title', 'Input Data Sertifikasi'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        
        <?php
            // dd($company);
        ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('wizard')->html();
} elseif ($_instance->childHasBeenRendered('Y9OwjmW')) {
    $componentId = $_instance->getRenderedChildComponentId('Y9OwjmW');
    $componentTag = $_instance->getRenderedChildComponentTagName('Y9OwjmW');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Y9OwjmW');
} else {
    $response = \Livewire\Livewire::mount('wizard');
    $html = $response->html();
    $_instance->logRenderedChild('Y9OwjmW', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projek\gpci\resources\views/client/add-sertifikasi.blade.php ENDPATH**/ ?>