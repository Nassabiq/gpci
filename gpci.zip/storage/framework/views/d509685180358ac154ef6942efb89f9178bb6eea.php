<div>
    <?php dump($document); ?>
</div>
<?php /**PATH C:\Projek\gpci\resources\views/livewire/approve.blade.php ENDPATH**/ ?>