
<?php $__env->startSection('title', 'Approve Document'); ?>
<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('approve-dokumen')->html();
} elseif ($_instance->childHasBeenRendered('dWgsUYF')) {
    $componentId = $_instance->getRenderedChildComponentId('dWgsUYF');
    $componentTag = $_instance->getRenderedChildComponentTagName('dWgsUYF');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('dWgsUYF');
} else {
    $response = \Livewire\Livewire::mount('approve-dokumen');
    $html = $response->html();
    $_instance->logRenderedChild('dWgsUYF', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projek\gpci\resources\views/client/approve-dokumen.blade.php ENDPATH**/ ?>