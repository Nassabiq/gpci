
<?php $__env->startSection('title', 'Dokumen Sertifikasi'); ?>
<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('upload-document')->html();
} elseif ($_instance->childHasBeenRendered('2RkrcY0')) {
    $componentId = $_instance->getRenderedChildComponentId('2RkrcY0');
    $componentTag = $_instance->getRenderedChildComponentTagName('2RkrcY0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('2RkrcY0');
} else {
    $response = \Livewire\Livewire::mount('upload-document');
    $html = $response->html();
    $_instance->logRenderedChild('2RkrcY0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function() {
            bsCustomFileInput.init()
        })

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projek\gpci\resources\views/client/dokumen-sertifikasi.blade.php ENDPATH**/ ?>