
<?php $__env->startSection('title', 'Detail Penilaian Sertifikasi'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('approve-sertifikasi', ['product'=> $product->id])->html();
} elseif ($_instance->childHasBeenRendered('XbGgbkk')) {
    $componentId = $_instance->getRenderedChildComponentId('XbGgbkk');
    $componentTag = $_instance->getRenderedChildComponentTagName('XbGgbkk');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('XbGgbkk');
} else {
    $response = \Livewire\Livewire::mount('approve-sertifikasi', ['product'=> $product->id]);
    $html = $response->html();
    $_instance->logRenderedChild('XbGgbkk', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projek\gpci\resources\views/client/detail-approve-sertifikasi.blade.php ENDPATH**/ ?>