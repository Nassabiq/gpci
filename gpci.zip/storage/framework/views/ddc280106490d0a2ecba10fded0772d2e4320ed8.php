<div>
    <div class="card card-outline card-teal p-4">
        <div class="card-body setup-content">
            
            <div class=" col-md-12">
                <h3 class="mx-0">Informasi Perusahaan</h3>
                <hr>
                
                <div class="form-group row">
                    <label>Nama Perusahaan:</label>
                    <input type="text" wire:model="nama_perusahaan" class="form-control form-control-sm"
                        id="nama_perusahaan" placeholder="Nama Perusahaan ...">
                    <?php $__errorArgs = ['nama_perusahaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="form-group row">
                    <label>Email:</label>
                    <input type="email" wire:model="email_perusahaan" class="form-control form-control-sm"
                        id="email_perusahaan" placeholder="Email Perusahaan ...">
                    <?php $__errorArgs = ['email_perusahaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="form-group row">
                    <label>Alamat Perusahaan:</label>
                    <input type="text" wire:model="alamat_perusahaan" class="form-control form-control-sm"
                        id="alamat_perusahaan" placeholder="Alamat Perusahaan ...">
                    <?php $__errorArgs = ['alamat_perusahaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>


                
                <div class="row">
                    <div class="form-group col-lg-2 col-md-2 col-sm-12 pl-0">
                        <label for="title">Kode Pos:</label>
                        <input type="text" wire:model="kodepos_perusahaan" class="form-control form-control-sm"
                            id="kodepos_perusahaan" placeholder="Kode Pos...">
                        <?php $__errorArgs = ['kodepos_perusahaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group col-5 col-md-5 col-sm-6 col-6 pl-0">
                        <label for="title">No Telp:</label>
                        <input type="text" wire:model="no_telp_perusahaan" class="form-control form-control-sm"
                            id="no_telp_perusahaan" placeholder="No. Telp ...">
                        <?php $__errorArgs = ['no_telp_perusahaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group col-5 col-md-5 col-sm-6 col-6 pl-0">
                        <label for="title">Fax:</label>
                        <input type="text" wire:model="fax_perusahaan" class="form-control form-control-sm"
                            id="fax_perusahaan" placeholder="Fax ...">
                        <?php $__errorArgs = ['fax_perusahaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                
                <div class="row">
                    <div class="form-group col-lg-6 col-md-6 col-sm-12 pl-0">
                        <label for="title">No Akta Notaris:</label>
                        <input type="text" wire:model="no_akta_notaris" class="form-control form-control-sm"
                            id="no_akta_notaris" placeholder="No. Akta Notaris ...">
                        <?php $__errorArgs = ['no_akta_notaris'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group col-lg-6 col-md-6 col-sm-12 pl-0">
                        <label for="title">No. Surat Izin Usaha Perdagangan (SIUP):</label>
                        <input type="text" wire:model="no_siup" class="form-control form-control-sm" id="no_siup"
                            placeholder="No. SIUP ...">
                        <?php $__errorArgs = ['no_siup'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                
                <div class="row">
                    <div class="form-group col-lg-6 col-md-6 col-12 pl-0">
                        <label for="title">No. Tanda Daftar Perusahaan (TDP):</label>
                        <input type="text" wire:model="no_tdp" class="form-control form-control-sm" id="no_tdp"
                            placeholder="No. TDP ...">
                        <?php $__errorArgs = ['no_tdp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group col-lg-6 col-md-6 col-12 pl-0">
                        <label for="title">NPWP:</label>
                        <input type="text" wire:model="no_npwp" class="form-control form-control-sm" id="no_npwp"
                            placeholder="No. NPWP ...">
                        <?php $__errorArgs = ['no_npwp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                
                <div class="form-group row">
                    <label>No. Angka Pengenal Importir(API):</label>
                    <input type="text" wire:model="no_api" class="form-control form-control-sm" id="no_api"
                        placeholder="No. API ...">
                    <?php $__errorArgs = ['no_api'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="row">
                    <div class="form-group col-lg-6 col-md-6 col-12 pl-0">
                        <label for="title">Apakah Anda Pernah Mendaftar Sertifikasi Ekolabel?</label> <br>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="sertifikasi_ekolabel" id="radio_yes"
                                value="0" wire:model="sertifikasi_ekolabel">
                            <label class="form-check-label">Iya</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="sertifikasi_ekolabel" id="radio_tidak"
                                value="1" wire:model="sertifikasi_ekolabel">
                            <label class="form-check-label">Tidak</label>
                        </div>
                    </div>
                    <div class="form-group col-lg-6 col-md-6 col-12 pl-0  <?php echo e($sertifikasi_ekolabel != 0 ? 'displayNone' : ''); ?>"
                        id="lembaga">
                        <label for="title">Jika Pernah, Sebutkan Nama Lembaganya: <sup
                                class="text-danger">*optional</sup></label>
                        <input type="text" wire:model="lembaga_ekolabel" class="form-control form-control-sm"
                            id="lembaga_ekolabel" placeholder="Lembaga Ekolabel..." value="2">
                        <?php $__errorArgs = ['lembaga_ekolabel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                
                <div class="form-group row">
                    <label>Website Perusahaan:</label>
                    <input type="text" wire:model="website_perusahaan" class="form-control form-control-sm"
                        id="website_perusahaan" placeholder="Website Perusahaan ...">
                    <?php $__errorArgs = ['website_perusahaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="contact-person-1">
                    <div class="form-group row">
                        <label class="col-12 px-0">Contact Person 1:</label> <br>
                        
                        <div class="cp col-lg-6 col-md-12 col-12 pl-0">
                            <input type="text" wire:model="nama1" class="form-control form-control-sm" id="nama1"
                                placeholder="Nama ...">
                            <?php $__errorArgs = ['nama1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="cp col-lg-6 col-md-12 col-12 px-0">
                            <input type="text" wire:model="jabatan1" class="form-control form-control-sm" id="jabatan1"
                                placeholder="Jabatan...">
                            <?php $__errorArgs = ['jabatan1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        
                        <div class="cp col-lg-6 col-md-12 col-12 pl-0">
                            <input type="text" wire:model="no_hp1" class="form-control form-control-sm" id="no_hp1"
                                placeholder="No Handphone (WA) ...">
                            <?php $__errorArgs = ['no_hp1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="cp col-lg-6 col-md-12 col-12 px-0">
                            <input type="email" wire:model="email1" class="form-control form-control-sm" id="email1"
                                placeholder="Email...">
                            <?php $__errorArgs = ['email1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        
                        <div class="cp col-lg-6 col-md-12 col-12 pl-0">
                            <input type="text" wire:model="no_telp1" class="form-control form-control-sm" id="no_telp1"
                                placeholder="No Telp ...">
                            <?php $__errorArgs = ['no_telp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="cp col-lg-6 col-md-12 col-12 px-0">
                            <input type="text" wire:model="fax1" class="form-control form-control-sm" id="fax1"
                                placeholder="No Fax...">
                            <?php $__errorArgs = ['fax1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="contact-person-2">
                    <div class="form-group row">
                        <label class="col-12 px-0">Contact Person 2: <sup class="text-danger">*optional</sup>
                        </label> <br>
                        
                        <div class="cp col-lg-6 col-md-12 col-12 pl-0">
                            <input type="text" wire:model="nama2" class="form-control form-control-sm" id="nama2"
                                placeholder="Nama ...">
                            <?php $__errorArgs = ['nama2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="cp col-lg-6 col-md-12 col-12 px-0">
                            <input type="text" wire:model="jabatan2" class="form-control form-control-sm" id="jabatan2"
                                placeholder="Jabatan...">
                            <?php $__errorArgs = ['jabatan2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        
                        <div class="cp col-lg-6 col-md-12 col-12 pl-0">
                            <input type="text" wire:model="no_hp2" class="form-control form-control-sm" id="no_hp2"
                                placeholder="No Handphone (WA) ...">
                            <?php $__errorArgs = ['no_hp2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="cp col-lg-6 col-md-12 col-12 px-0">
                            <input type="email" wire:model="email2" class="form-control form-control-sm" id="email2"
                                placeholder="Email...">
                            <?php $__errorArgs = ['email2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        
                        <div class="cp col-lg-6 col-md-12 col-12 pl-0">
                            <input type="text" wire:model="no_telp2" class="form-control form-control-sm" id="no_telp2"
                                placeholder="No Telp ...">
                            <?php $__errorArgs = ['no_telp2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="cp col-lg-6 col-md-12 col-12 px-0">
                            <input type="text" wire:model="fax2" class="form-control form-control-sm" id="fax2"
                                placeholder="No Fax...">
                            <?php $__errorArgs = ['fax2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <br>
                <button class="btn btn-primary nextBtn pull-right next-button" type="button"
                    wire:click="uploadPerusahaan">Upload</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Projek\gpci\resources\views/livewire/import.blade.php ENDPATH**/ ?>