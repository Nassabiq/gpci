<aside class="main-sidebar <?php echo e(config('adminlte.classes_sidebar', 'sidebar-dark-success elevation-4')); ?>"
    style="height: 100%">

    
    <?php if(config('adminlte.logo_img_xl')): ?>
        <?php echo $__env->make('adminlte::partials.common.brand-logo-xl', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('adminlte::partials.common.brand-logo-xs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user panel (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="info">
                <a href="<?php echo e(route('account')); ?>" class="d-block"><?php echo e(ucfirst(Auth::user()->name)); ?></a>
            </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar nav-child-indent flex-column" data-widget="treeview" role="menu">
                
                <li class="nav-item has-treeview">
                    <a href="<?php echo e(route('home')); ?>" class="nav-link <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-home"></i>
                        <p>
                            Home
                        </p>
                    </a>
                </li>
                <?php if(Auth::user()->hasRole('client') || Auth::user()->hasRole('super-admin') || Auth::user()->hasRole('admin')): ?>
                    <li class="nav-item has-treeview <?php echo e(request()->segment(1) == 'sertifikasi' ? 'menu-open' : ''); ?>">
                        <a href="#" class="nav-link <?php echo e(request()->segment(1) == 'sertifikasi' ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-book-reader"></i>
                            <p>
                                Sertifikasi
                                <i class="right fas fa-angle-right"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if(Auth::user()->hasRole('client') || Auth::user()->hasRole('super-admin')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('show-sertifikasi')); ?>"
                                        class="nav-link text-sm <?php echo e(request()->routeIs('show-sertifikasi') ? 'active' : ''); ?>">
                                        <i class="fas fa-briefcase nav-icon"></i>
                                        <p>Data Sertifikasi</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('add-sertifikasi')); ?>"
                                        class="nav-link text-sm <?php echo e(request()->routeIs('add-sertifikasi') ? 'active' : ''); ?>">
                                        <i class="fas fa-plus-circle nav-icon"></i>
                                        <p>Pendaftaran Sertifikasi</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('dokumen-sertifikasi')); ?>"
                                        class="nav-link text-sm <?php echo e(request()->routeIs('dokumen-sertifikasi') ? 'active' : ''); ?>">
                                        <i class="fas fa-file nav-icon"></i>
                                        <p>Dokumen Sertifikasi</p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if(Auth::user()->hasRole('admin') || Auth::user()->hasRole('super-admin')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('data-sertifikasi')); ?>"
                                        class="nav-link text-sm <?php echo e(request()->routeIs('data-sertifikasi') ? 'active' : ''); ?>">
                                        <i class="fas fa-briefcase nav-icon"></i>
                                        <p>Data Sertifikasi</p>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if(Auth::user()->hasRole('super-admin') || Auth::user()->hasRole('admin')): ?>
                    <li class="nav-item has-treeview <?php echo e(request()->segment(1) == 'import' ? 'menu-open' : ''); ?>">
                        <a href="#" class="nav-link <?php echo e(request()->segment(1) == 'import' ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-file-upload"></i>
                            <p>
                                Import Data
                                <i class="right fas fa-angle-right"></i>
                            </p>
                        </a>

                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="<?php echo e(route('import-data-sertifikasi')); ?>"
                                    class="nav-link text-sm <?php echo e(request()->routeIs('import-data-sertifikasi') ? 'active' : ''); ?>">
                                    <i class="fas fa-file-import nav-icon"></i>
                                    <p>Import Data</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('import-checklist-dokumen')); ?>"
                                    class="nav-link text-sm <?php echo e(request()->routeIs('import-checklist-dokumen') ? 'active' : ''); ?>">
                                    <i class="fas fa-file-import nav-icon"></i>
                                    <p>Checklist Dokumen</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('add-kategori-produk')); ?>"
                                    class="nav-link text-sm <?php echo e(request()->routeIs('add-kategori-produk') ? 'active' : ''); ?>">
                                    <i class="fas fa-folder-plus nav-icon"></i>
                                    <p>Add Kategori Produk</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if(Auth::user()->hasRole('verifikator') || Auth::user()->hasRole('super-admin') || Auth::user()->hasRole('admin')): ?>
                    <li class="nav-item has-treeview <?php echo e(request()->segment(1) == 'penilaian' ? 'menu-open' : ''); ?>">
                        <a href="#" class="nav-link <?php echo e(request()->segment(1) == 'penilaian' ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-circle-notch"></i>
                            <p>
                                Penilaian
                                <i class="right fas fa-angle-right"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if(Auth::user()->hasRole('verifikator') || Auth::user()->hasRole('super-admin')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('penilaian-sertifikasi')); ?>"
                                        class="nav-link text-sm <?php echo e(request()->routeIs('penilaian-sertifikasi') ? 'active' : ''); ?>">
                                        <i class="fas fa-pen-alt nav-icon"></i>
                                        <p>Penilaian Sertifikasi</p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if(Auth::user()->hasRole('super-admin') || Auth::user()->hasRole('admin')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('input-angket-penilaian')); ?>"
                                        class="nav-link text-sm <?php echo e(request()->routeIs('input-angket-penilaian') ? 'active' : ''); ?>">
                                        <i class="fas fa-pen-alt nav-icon"></i>
                                        <p>Input Angket Penilaian</p>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if(Auth::user()->hasRole('admin') || Auth::user()->hasRole('super-admin')): ?>
                    <li class="nav-item has-treeview <?php echo e(request()->segment(1) == 'approve' ? 'menu-open' : ''); ?>">
                        <a href="#" class="nav-link <?php echo e(request()->segment(1) == 'approve' ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-check-double"></i>
                            <p>
                                Approve Data
                                <i class="right fas fa-angle-right"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="<?php echo e(route('approve-sertifikasi')); ?>"
                                    class="nav-link text-sm <?php echo e(request()->routeIs('approve-sertifikasi') ? 'active' : ''); ?>">
                                    <i class="fas fa-check nav-icon"></i>
                                    <p>Approve Sertifikasi</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('approve-dokumen')); ?>"
                                    class="nav-link text-sm <?php echo e(request()->routeIs('approve-dokumen') ? 'active' : ''); ?>">
                                    <i class="fas fa-stamp nav-icon"></i>
                                    <p>Approve Dokumen</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>

                <?php if(Auth::user()->hasRole('admin') || Auth::user()->hasRole('super-admin')): ?>
                    
                    <li class="nav-item has-treeview <?php echo e(request()->segment(1) == 'user' ? 'menu-open' : ''); ?>">
                        <a href="#" class="nav-link <?php echo e(request()->segment(1) == 'user' ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-users"></i>
                            <p>
                                User Administration
                                <i class="right fas fa-angle-right"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="<?php echo e(route('approve-user')); ?>"
                                    class="nav-link text-sm <?php echo e(request()->routeIs('approve-user') ? 'active' : ''); ?>">
                                    <i class="fas fa-user-check nav-icon"></i>
                                    <p>Approve User</p>
                                </a>
                            </li>
                            <?php if(Auth::user()->hasRole('super-admin')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('user-management')); ?>"
                                        class="nav-link text-sm <?php echo e(request()->routeIs('user-management') ? 'active' : ''); ?>">
                                        <i class="fas fa-user-cog nav-icon"></i>
                                        <p>Manage User</p>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <li class="nav-item has-treeview">
                    <a href="<?php echo e(route('account')); ?>"
                        class="nav-link <?php echo e(request()->routeIs('account') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-user-circle"></i>
                        <p>
                            Account
                        </p>
                    </a>
                </li>
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>

</aside>
<?php /**PATH C:\Projek\gpci\resources\views/vendor/adminlte/partials/sidebar/left-sidebar.blade.php ENDPATH**/ ?>