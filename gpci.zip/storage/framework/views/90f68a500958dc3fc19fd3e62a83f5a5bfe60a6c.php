<div>
    
    <h4>Detail Penilaian Sertifikasi</h4>
    <hr>
    <ul>
        <li>Untuk memulai penilaian, harap ubah status produk pada tombol dibawah</li>
        <li>Template Form Penilaian bisa diunduh pada list yang ada dibawah ini</li>
    </ul>
    <?php if($produk->status == 2): ?>
        <button class="btn btn-outline-primary my-2 float-right" data-toggle="modal" data-target="#modalConfirm">
            Approve
        </button>
    <?php elseif($produk->status == 1): ?>
    <?php else: ?>
        <button class="btn btn-primary my-2 float-right">
            Produk telah disertifikasi
        </button>
    <?php endif; ?>
    <div class="modal fade" id="modalConfirm" tabindex="-1" wire:ignore.self>
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body">
                    <h5>Approve Dokumen?</h5>
                    <p>Score untuk sertifikasi : </p>
                    <select class="custom-select" wire:model="scoring_id">
                        <option>Pilih Score Sertifikasi</option>
                        <option value="1">Bronze</option>
                        <option value="2">Silver</option>
                        <option value="3">Gold</option>
                    </select>
                    <?php $__errorArgs = ['scoring_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Back</button>

                    <button type="button" wire:click="approveSertifikasi(<?php echo e($produk->id); ?>)"
                        class="btn btn-primary">Yes</button>
                </div>
            </div>
        </div>
    </div>
    <?php
        $contactPlant = json_decode($produk->pabrik->contact);
        $contactPerusahaan = json_decode($produk->pabrik->perusahaan->contact);
    ?>
    <table class="table table-sm">
        <tbody>
            <tr>
                <th class="table-first">Nama Produk</th>
                <td class="table-second">:</td>
                <td><?php echo e($produk->nama_produk); ?></td>
            </tr>
            <tr>
                <th class="table-first">Perusahaan</th>
                <td class="table-second">:</td>
                <td><?php echo e($produk->pabrik->perusahaan->nama_perusahaan); ?></td>
            </tr>
            <tr>
                <th class="table-first">Contact Perusahaan</th>
                <td class="table-second">:</td>
                <td>
                    <ul>
                        <li>Nama : <?php echo e($contactPerusahaan->cp_1->nama); ?></li>
                        <li>Email : <?php echo e($contactPerusahaan->cp_1->email); ?></li>
                        <li>No. Telp : <?php echo e($contactPerusahaan->cp_1->no_hp); ?></li>
                    </ul>
                </td>
            </tr>
            <tr>
                <th class="table-first">Plant</th>
                <td class="table-second">:</td>
                <td><?php echo e($produk->pabrik->nama_fasilitas); ?></td>
            </tr>
            <tr>
                <th class="table-first">Contact Plant</th>
                <td class="table-second">:</td>
                <td>
                    <ul>
                        <li>Nama : <?php echo e($contactPlant->nama); ?></li>
                        <li>Email : <?php echo e($contactPlant->email); ?></li>
                        <li>No. Telp : <?php echo e($contactPlant->no_hp); ?></li>
                    </ul>
                </td>
            </tr>
        </tbody>
    </table>

    <h5>List Dokumen Audit Sertifikasi</h5>
    <table class="table">
        <thead class="thead-light">
            <tr>
                <th scope="col">List</th>
                <th scope="col">Status</th>
                <th scope="col">Dokumen</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Angket Penilaian</td>
                <td>
                    <span
                        class="badge <?php echo e($produk->ratings->angket_penilaian !== null ? 'badge-success' : 'badge-danger'); ?>  badge-pill">
                        <?php if($produk->ratings->angket_penilaian !== null): ?>
                            <i class="fas fa-check"></i>
                        <?php else: ?>
                            <i class="fas fa-times"></i>
                        <?php endif; ?>
                    </span>
                </td>
                <?php if($this->produk->ratings->angket_penilaian): ?>
                    <td>
                        <a href="<?php echo e(asset('storage/dokumen_audit/' . $this->produk->nama_produk . '/' . $this->produk->ratings->angket_penilaian)); ?>"
                            class="btn btn-sm btn-success" target="_blank  ">Preview</a>
                    </td>
                <?php endif; ?>
            </tr>
            <tr>
                <td>Laporan Ringkas Verifikasi</td>
                <td>
                    <span
                        class="badge <?php echo e($produk->ratings->laporan_ringkas_verifikasi !== null ? 'badge-success' : 'badge-danger'); ?>  badge-pill">
                        <?php if($produk->ratings->laporan_ringkas_verifikasi !== null): ?>
                            <i class="fas fa-check"></i>
                        <?php else: ?>
                            <i class="fas fa-times"></i>
                        <?php endif; ?>
                    </span>
                </td>
                <?php if($this->produk->ratings->laporan_ringkas_verifikasi): ?>
                    <td>
                        <a href="<?php echo e(asset('storage/dokumen_audit/' . $this->produk->nama_produk . '/' . $this->produk->ratings->laporan_ringkas_verifikasi)); ?>"
                            class="btn btn-sm btn-success" target="_blank  ">Preview</a>
                    </td>
                <?php endif; ?>
            </tr>
            <tr>
                <td>Recommendation for Improvement</td>
                <td>
                    <span
                        class="badge <?php echo e($produk->ratings->recommendation_for_improvement !== null ? 'badge-success' : 'badge-danger'); ?>  badge-pill">
                        <?php if($produk->ratings->recommendation_for_improvement !== null): ?>
                            <i class="fas fa-check"></i>
                        <?php else: ?>
                            <i class="fas fa-times"></i>
                        <?php endif; ?>
                    </span>
                </td>
                <?php if($this->produk->ratings->recommendation_for_improvement): ?>
                    <td>
                        <a href="<?php echo e(asset('storage/dokumen_audit/' . $this->produk->nama_produk . '/' . $this->produk->ratings->recommendation_for_improvement)); ?>"
                            class="btn btn-sm btn-success" target="_blank  ">Preview</a>
                    </td>
                <?php endif; ?>
            </tr>
        </tbody>
    </table>
</div>
<?php $__env->startSection('js'); ?>

    <script>
        window.addEventListener('swal:error', event => {
            swal({
                title: event.detail.message,
                text: event.detail.text,
                icon: event.detail.type,
                dangerMode: true,
                timer: 1500,
            });
        });

    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Projek\gpci\resources\views/livewire/approve-sertifikasi.blade.php ENDPATH**/ ?>