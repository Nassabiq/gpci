<div>
    <h2>Checklist Dokumen </h2>
    <hr>

    <div class="d-flex mb-2 justify-content-between">
        <div class="col-3">
            <select class="custom-select" wire:model="kategori">
                <option value="">Kategori</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->categories); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <button class="btn btn-primary btn-sm" wire:click.prevent="add()">Tambah Dokumen</button>
    </div>
    <?php if(session()->has('message')): ?>
        <div class="alert alert-success" style="margin-top:30px;">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">No</th>
                <th scope="col">Nama Dokumen</th>
                <th scope="col">Kategori</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $no = 1;
            ?>
            <?php $__currentLoopData = $docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($no++); ?></th>
                    <td><?php echo e($doc->nama_dokumen); ?></td>
                    <td><?php echo e($doc->kategoriProduk->categories); ?></td>
                    <td>
                        <?php if($doc->kategoriProduk->id !== 100): ?>
                            <div class="d-flex">
                                <button type="button" class="btn btn-primary btn-sm"
                                    wire:click.prevent="edit(<?php echo e($doc); ?>)">Edit</button>
                                <button type="button" class="btn btn-danger btn-sm ml-2"
                                    wire:click="delete(<?php echo e($doc->id); ?>)">Delete</button>
                            </div>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="modal fade" id="addDokumen" tabindex="-1" wire:ignore.self data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog">
            <form autocomplete="off" wire:submit.prevent="<?php echo e($updateMode ? 'editDokumen' : 'addDokumen'); ?>">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">
                            <?php if($updateMode): ?>
                                <span>Edit Checklist Dokumen</span>
                            <?php else: ?>
                                <span>Tambah Checklist Dokumen</span>
                            <?php endif; ?>
                        </h5>
                        <button type="button" class="close" wire:click.prevent="close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <?php if($updateMode): ?>
                                <input type="hidden" wire:model="doc_id">
                            <?php endif; ?>
                            <label>Nama Dokumen</label>
                            <input class="form-control" type="text" placeholder="Nama Dokumen"
                                wire:model="nama_dokumen">
                            <?php $__errorArgs = ['nama_dokumen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label>Kategori Dokumen</label>
                            <select class="custom-select" wire:model="kategori_input">
                                <option value="">Kategori</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>">
                                        <?php echo e($category->categories); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['kategori_input'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" wire:click.prevent="close">Close</button>
                        <button type="submit" class="btn btn-primary">
                            <?php if($updateMode): ?>
                                <span>Edit</span>
                            <?php else: ?>
                                <span>Save</span>
                            <?php endif; ?>
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->startSection('js'); ?>
    <script>
        window.addEventListener('hide-modal', () => {
            $('.modal').modal('hide');
            $('.modal-backdrop').remove();
        });

    </script>
    <script>
        window.addEventListener('show-modal', event => {
            $('.modal').modal('show');
        });

    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Projek\gpci\resources\views/livewire/checklist-dokumen.blade.php ENDPATH**/ ?>