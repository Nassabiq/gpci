<div>
    
    <div class="container">
        <h2>Dokumen Sertifikasi</h2>
        <p>
            Dokumen yang diperbolehkan harus berbentuk <b>PDF</b> <br> dan setiap dokumen memiliki ukuran maksimal 2MB
        </p>
        <hr>
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success" role="alert"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <div class="col-3 my-3">
            <select class="custom-select" id="produk" wire:model="product">
                <option value="" selected>Jenis Produk</option>
                <?php if($company): ?>
                    <?php $__currentLoopData = $company->factories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $item->produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($produk->id); ?>">
                                <?php echo e($produk->nama_produk); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>
        </div>
        <?php if($document): ?>
            <div class="table-responsive">
                <table class="table">
                    <thead class="thead-light">
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">Dokumen</th>
                            <th scope="col">Nama File</th>
                            <th scope="col">Action</th>
                            <th scope="col">Status</th>
                            <th scope="col">Keterangan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $no = 1;
                        ?>
                        <?php $__currentLoopData = $document->document; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td>
                                    <?php echo e($doc->nama_dokumen); ?>

                                </td>
                                <?php if($doc->pivot->nama_dokumen == null): ?>
                                    <td>
                                        <input type="file" wire:model="nama_dokumen">
                                        <?php $__errorArgs = ['nama_dokumen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                    <td>
                                        <button type="button" class="btn btn-sm btn-primary ml-2"
                                            wire:click="uploadDokumen(<?php echo e($doc->id); ?>, '<?php echo e($doc->nama_dokumen); ?>')">Upload</button>
                                    </td>
                                <?php else: ?>
                                    <td>
                                        <?php echo e($doc->pivot->nama_dokumen); ?>

                                        <div class="collapse mt-2" id="editakta" wire:ignore.self>
                                            <div class="card card-body d-flex">
                                                <div class="d-flex">
                                                    <input type="file" wire:model="nama_dokumen">
                                                    <button type="button" class="btn btn-sm btn-primary"
                                                        wire:click="uploadDokumen(<?php echo e($doc->pivot->id); ?>, '<?php echo e($doc->pivot->nama_dokumen); ?>')">Edit</button>
                                                </div>
                                                <?php $__errorArgs = ['nama_dokumen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="d-flex">
                                            <a href="<?php echo e(asset('storage/checklist-dokumen/' . $this->company->nama_perusahaan . '/' . $doc->pivot->nama_dokumen)); ?>"
                                                class="btn btn-sm btn-primary" target="_blank">Dokumen</a>
                                            <?php if($doc->pivot->status !== 2): ?>
                                                <button class="btn btn-sm btn-success ml-2" data-toggle="collapse"
                                                    data-target="#editakta">Edit</button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                <?php endif; ?>
                                <td>
                                    <?php switch($doc->pivot->status):
                                        case (0): ?>
                                        <span class="badge badge-pill badge-secondary">kosong</span>
                                        <?php break; ?>
                                        <?php case (1): ?>
                                        <span class="badge badge-pill badge-danger">Belum diapprove</span>
                                        <?php break; ?>
                                        <?php case (2): ?>
                                        <span class="badge badge-pill badge-success">Approved</span>
                                        <?php break; ?>
                                        <?php default: ?>
                                    <?php endswitch; ?>
                                </td>
                                <td>
                                    <?php echo e($doc->pivot->keterangan); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="modal fade" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="document" id="document">

                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-primary">Save changes</button>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php $__env->startSection('js'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfobject/2.2.4/pdfobject.js"
        integrity="sha512-pOkH5W0iYlsujt/wd8KQwGJlc76bfVQ+gN3wNj2jE671otBKfTqSU17mdb74MdGqU2G7ScJqH9BqQ8UvWL0hdg=="
        crossorigin="anonymous"></script>

    <script src="https://cdn.jsdelivr.net/npm/bs-custom-file-input/dist/bs-custom-file-input.min.js"> </script>

    <script>
        window.addEventListener('swal:error', event => {
            swal({
                title: event.detail.message,
                text: event.detail.text,
                icon: event.detail.type,
                dangerMode: true,
                timer: 1500,
            });
        });
        // window.livewire.on('hideModal', () => {
        //     $('.modal').modal('hide');
        // });
        // $(document).on('click', '.showPDF', function() {
        //     let url = $(this).data('url');
        //     console.log(url);
        //     $('.modal').modal('show');
        //     let doc = $('#document');
        //     // doc.append('<iframe src="' + url + '" width="100%" height="500px" type="application/pdf"></iframe>');
        //     PDFObject.embed(url, '#document')

        //     $(".modal").on('hidden.bs.modal', function() {
        //         let url1 = $(this).data('url', null);
        //     });
        // });

    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Projek\gpci\resources\views/livewire/upload-document.blade.php ENDPATH**/ ?>