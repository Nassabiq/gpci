
<?php $__env->startSection('title', 'Approve Data Sertifikasi'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">

        <h2>Approve Sertifikasi</h2>
        <hr>
        <table class="table">
            <thead class="thead-light">
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Nama Produk</th>
                    <th scope="col">Nama Perusahaan</th>
                    <th scope="col">Pabrik</th>
                    <th scope="col">Status</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>

            <tbody>
                <?php
                    $i = 1;
                ?>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($i++); ?></th>
                        <td><?php echo e($product->nama_produk); ?></td>
                        <td><?php echo e($product->pabrik->perusahaan->nama_perusahaan); ?></td>
                        <td><?php echo e($product->pabrik->nama_fasilitas); ?></td>
                        <td>
                            <?php if($product->status == 1): ?>
                                <span class="badge badge-pill badge-danger">Belum Diverifikasi</span>
                            <?php elseif($product->status == 2): ?>
                                <span class="badge badge-pill badge-warning">Sedang Diverifikasi</span>
                            <?php elseif($product->status == 3): ?>
                                <span class="badge badge-pill badge-success">Terverifikasi</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(url('/approve/approve-sertifikasi/' . $product->id)); ?>"
                                class="btn btn-sm btn-primary">Details</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projek\gpci\resources\views/client/approve-sertifikasi.blade.php ENDPATH**/ ?>