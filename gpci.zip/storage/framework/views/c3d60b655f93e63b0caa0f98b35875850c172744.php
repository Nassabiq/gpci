
<?php $__env->startSection('title', 'Approve User'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Approve User</h2>
        <hr>
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <table class="table">
            <thead class="thead-light">
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Username</th>
                    <th scope="col">Email</th>
                    <th scope="col">Role</th>
                    <th scope="col">Status</th>
                    <th scope="col">No. Telp</th>
                    <th scope="col">Tgl Mendaftar</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $no = 1;
                ?>
                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($no++); ?></th>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->email); ?></td>
                        <?php $__currentLoopData = $item->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td><?php echo e(Str::ucfirst($role->name)); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td>
                            <?php if($item->status == 0): ?>
                                <span class="badge badge-pill badge-danger">Belum diaktivasi</span>
                            <?php else: ?>
                                <span class="badge badge-pill badge-success">Sudah diaktivasi</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php echo e($item->phone); ?>

                        </td>
                        <td>
                            <?php echo e(Carbon\Carbon::parse($item->created_at)->locale('id')->diffForHumans()); ?>

                        </td>
                        <td>
                            <?php if($item->status == 0): ?>
                                <button type="submit" class="btn btn-sm btn-primary showModal" data-id="<?php echo e($item->id); ?>"
                                    data-name="<?php echo e($item->name); ?>">
                                    Approve
                                </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="d-flex justify-content-center">
            <?php echo e($user->links()); ?>

        </div>
    </div>
    <div class="modal fade" tabindex="-1" data-backdrop="static">
        <div class="modal-dialog">
            <form method="post" id="approveUser">
                <?php echo csrf_field(); ?>
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Approve Akun</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        Approve akun ini?
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).on('click', '.showModal', function() {
            let id = $(this).data('id');
            let nama = $(this).data('name');
            var form = $('#approveUser');
            $('.modal').modal('show');

            form.attr('action', '/user/approve-user/' + id)
        })

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projek\gpci\resources\views/client/approve-user.blade.php ENDPATH**/ ?>