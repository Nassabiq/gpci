<table width="100%" cellpadding="0" cellspacing="0" border="0">
	<tr>
		<td bgcolor="<?php echo e(isset($color) ? $color : '#ef3101'); ?>" nowrap><img border="0" src="<?php echo e(Request::getSchemeAndHttpHost()); ?>/vendor/beautymail/assets/images/widgets/spacer.gif" width="5" height="1"></td>
		<td width="100%" bgcolor="#ffffff">

			<table width="100%" cellpadding="20" cellspacing="0" border="0">
				<tr>
					<td bgcolor="#ffffff" class="contentblock"><?php /**PATH C:\Projek\gpci\vendor\snowfire\beautymail\src\Snowfire\Beautymail/../../views/templates/widgets/articleStart.blade.php ENDPATH**/ ?>