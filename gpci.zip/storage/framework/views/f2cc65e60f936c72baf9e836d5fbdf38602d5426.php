<div>
    
    <div class="row">
        <div class="col-lg-4 header">
            <div class="vrtwiz card">
                <ul class="verticalwiz card-body container mt-4">
                    <li class="<?php echo e($currentStep != 1 ? '' : 'active'); ?> d-flex">
                        <a href="#"> <span class="step">1</span> </a>
                        <p class="title">Informasi Produk</p>
                    </li>
                    <li class="<?php echo e($currentStep != 2 ? '' : 'active'); ?> d-flex">
                        <a href="#"> <span class="step">2</span> </a>
                        <p class="title">Submission</p>
                    </li>
                </ul>
            </div>
        </div>

        <div class="col-lg-8 card card-outline card-teal">
            <div class="container p-4">
                <div class="card-body setup-content <?php echo e($currentStep != 1 ? 'displayNone' : ''); ?>" id="step1">
                    
                    <div class="col-md-12">
                        <h3>Informasi Produk</h3>
                        <hr>
                        
                        <div class="form-group row">
                            <label>Nama Pabrik:</label>
                            <select class="form-control form-control-sm" wire:model="nama_pabrik" id="nama_pabrik"
                                onchange="val()">
                                <option>Nama Pabrik</option>
                                <?php if($company): ?>
                                    <?php $__currentLoopData = $company->factories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama_fasilitas); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                            <?php $__errorArgs = ['jenis_sertifikasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="form-group row">
                            <label>Nama Produk:</label>
                            <input type="text" wire:model="nama_produk" class="form-control form-control-sm"
                                id="nama_produk" placeholder="Nama Produk ...">
                            <?php $__errorArgs = ['nama_produk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group row">
                            <label>Tipe / Model:</label>
                            <input type="text" wire:model="tipe_model" class="form-control form-control-sm"
                                id="tipe_model" placeholder="Tipe / Model ...">
                            <?php $__errorArgs = ['tipe_model'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group row">
                            
                            <div class="cp col-lg-3 col-md-12 col-12 pl-0">
                                <label>Ukuran</label>
                                <input type="text" wire:model="ukuran" class="form-control form-control-sm" id="ukuran"
                                    placeholder="Ukuran...">
                                <?php $__errorArgs = ['ukuran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div class="cp col-lg-9 col-md-12 col-12 px-0">
                                <label>Merk Dagang:</label>
                                <input type="text" wire:model="merk_dagang" class="form-control form-control-sm"
                                    id="merk_dagang" placeholder="Merk Dagang...">
                                <?php $__errorArgs = ['merk_dagang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        
                        <div class="form-group row">
                            <label>Deskripsi Produk:</label>
                            <textarea class="form-control" id="deskripsi" rows="3"
                                wire:model="deskripsi_produk"></textarea>
                            <?php $__errorArgs = ['deskripsi_produk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="form-group row">
                            <label>Produk yang akan disertifikasi:</label>
                            <select class="custom-select custom-select-sm" wire:model="kategori_produk"
                                id="inputGroupSelect02">
                                <option value="">Choose...</option>
                                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>">
                                        <?php echo e($item->categories); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        
                        <div class="form-group row">
                            <label>Jenis Sertifikasi :</label>
                            <select class="form-control form-control-sm" wire:model="jenis_sertifikasi">
                                <option>Jenis Sertifikasi</option>
                                <option value="1">Pengajuan Baru</option>
                                <option value="2">Perpanjangan</option>
                            </select>
                            <?php $__errorArgs = ['jenis_sertifikasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <label>Foto Produk:</label>
                        <div class="input-group mb-3 mx-0">
                            <div class="custom-file">
                                <input type="file" class="custom-file-input"  name="foto_produk[]"
                                    accept="image/*" wire:model="foto_produk" multiple id="photoproduk">
                                <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                            </div>
                        </div>
                        <?php $__currentLoopData = $foto_produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card d-inline-block">
                                <?php if($photos): ?>
                                    <div class="card-body">
                                        <img width="150px" height="150px" style="object-fit: cover"
                                            src="<?php echo e($photos->temporaryUrl()); ?>">
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__errorArgs = ['foto_produk.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        
                        
                        <div class="form-group row">
                            <label>Tipe Pengemasan dan Ukuran:</label>
                            <input type="text" wire:model="tipe_pengemasan" class="form-control form-control-sm"
                                id="tipe_pengemasan" placeholder="Tipe Pengemasan dan Ukuran ...">
                            <?php $__errorArgs = ['tipe_pengemasan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <button class="btn btn-primary nextBtn next-button pull-right" wire:click="firstStepSubmit"
                            type="button">Next <i class="fas fa-long-arrow-alt-right pl-2"></i></button>
                    </div>
                </div>
                <div class="card-body setup-content <?php echo e($currentStep != 2 ? 'displayNone' : ''); ?>" id="step2">
                    <div class="col-md-12 konfirmasi">
                        <h3>Konfirmasi Pendaftaran Sertifikasi</h3>
                        <hr>

                        <h5>Informasi Produk</h5>

                        <table class="table table-sm table-borderless">
                            <tbody>
                                <tr>
                                    <td class="table-first">Nama Produk</td>
                                    <td>:</td>
                                    <td><?php echo e($nama_produk); ?></td>
                                </tr>
                                <tr>
                                    <td class="table-first">Tipe / Model</td>
                                    <td>:</td>
                                    <td><?php echo e($tipe_model); ?></td>
                                </tr>
                            </tbody>
                        </table>
                        <table class="table table-sm table-borderless">
                            <tbody>
                                <tr>
                                    <td class="table-first">Ukuran</td>
                                    <td class="table-second">:</td>
                                    <td class="table-third"><?php echo e($ukuran); ?></td>

                                    <td class="table-first">Merk Dagang</td>
                                    <td class="table-second">:</td>
                                    <td class="table-third"><?php echo e($merk_dagang); ?></td>
                                </tr>
                            </tbody>
                        </table>
                        <table class="table table-sm table-borderless">
                            <tbody>
                                <tr>
                                    <td class="table-first">Deskripsi Produk</td>
                                    <td class="table-second">:</td>
                                    <td class="table-third"><?php echo e($deskripsi_produk); ?></td>
                                </tr>
                                <tr>
                                    <td class="table-first">Tipe Pengemasan dan Ukuran</td>
                                    <td class="table-second">:</td>
                                    <td class="table-third"><?php echo e($tipe_pengemasan); ?></td>
                                </tr>
                            </tbody>
                        </table>
                        <button class="btn btn-danger nextBtn prev-button pull-right" type="button"
                            wire:click="back(1)"><i class="fas fa-long-arrow-alt-left pr-2"></i> Back</button>
                        <button class="btn btn-primary nextBtn next-button pull-right" type="button"
                            wire:click="submitForm">Submit</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startSection('js'); ?>
    <script>
        $(".nextBtn").click(function(e) {
            $(document).scrollTop(0)
        });

        $(document).ready(function() {
            $("#modalProduk").modal('show');
        });

        function val() {
            var pabrik = document.getElementById('nama_pabrik');
            var str = pabrik.options[pabrik.selectedIndex].text;
        }

    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Projek\gpci\resources\views/livewire/wizard-produk.blade.php ENDPATH**/ ?>