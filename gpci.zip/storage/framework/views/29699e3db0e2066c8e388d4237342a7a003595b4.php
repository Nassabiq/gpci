</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</div><?php /**PATH C:\Projek\gpci\vendor\snowfire\beautymail\src\Snowfire\Beautymail/../../views/templates/minty/contentEnd.blade.php ENDPATH**/ ?>