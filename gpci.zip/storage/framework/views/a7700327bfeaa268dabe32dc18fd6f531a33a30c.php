
<?php $__env->startSection('title', 'Input Data Sertifikasi'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('wizard-produk')->html();
} elseif ($_instance->childHasBeenRendered('uOr83tC')) {
    $componentId = $_instance->getRenderedChildComponentId('uOr83tC');
    $componentTag = $_instance->getRenderedChildComponentTagName('uOr83tC');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('uOr83tC');
} else {
    $response = \Livewire\Livewire::mount('wizard-produk');
    $html = $response->html();
    $_instance->logRenderedChild('uOr83tC', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projek\gpci\resources\views/client/add-produk.blade.php ENDPATH**/ ?>